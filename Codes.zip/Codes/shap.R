# shap空间异质性 ---------------------------------------------------------------

shap <- read.csv("shap_1007.csv")

shap <- shap %>% select(-X)
shap <- shap  %>% rename(abs_latitude = 1, MAT = 2)
# p1
maxVals <- apply(shap, 1, function(x) max((x))) 
colNames <- colnames(shap) 
maxCols <- apply(shap, 1, function(x) colNames[which.max(x)]) 
shap <- cbind(shap, maxVal=maxVals, maxCol=maxCols)
preddf<-readRDS("derived//06-2-preddf.rds")
preddata<-preddf %>% filter(Category=="Predicted") %>% select(all_of(predictors),x,y)
shap <- shap %>% mutate("x"=preddata$x) %>% mutate("y"=preddata$y) 
shap %>% names %>% writeLines
col_levels <- unique(shap$maxCol) 
maxcol <-  pull(shap$maxCol) %>% levels
maxcol <- unique(shap$maxCol)

shap %>% count(maxCol) 
# maxCol      n
# 1             D 174170
# 2           MAP 115785
# 3           MAT 101229
# 4  abs_latitude   2242
# 5       aridity 392461
# 6           cec  49045
# 7          clay  29147
# 8    difference  11176
# 9          elev  54686
# 10        phh2o     62
# 11     plant_PR  48258
# 12     plant_SR   3871
# 13    soil_temp   8727
shapdata <- shap  %>% mutate(Luis = preddata$Land_cover) 

shapdata$Lui = ifelse(shapdata$Luis =="C","Cropland",
                      ifelse(shapdata$Luis== "G","Grassland",
                             ifelse(shapdata$Luis=="F","Forest",
                                    ifelse(shapdata$Luis =="D","Desert","other"))))
shapdata <- shapdata[complete.cases(shapdata),]
map <- ggplot(shapdata, aes(x, y, fill = maxCol))+
  borders(fill = "grey90", colour = NA, ylim = c(-60, 90))+
  geom_tile(key_glyph = "polygon3")+
  coord_fixed(xlim = c(-180, 180), expand = FALSE)+
  scale_fill_manual( values = c("#543005", "#8C510A" ,"#BF812D" ,"#E7B10A","#DFC27D", "#F6E8C3" ,"#FFFEC4","#D7E5CA", "#C7EAE5","#A2CDB0", "#80CDC1" ,"#35978F"
                                ,"#01665E", "#003C30","#22668D"),
                     labels = c("LST_diff", "Aridity","Clay","Elevation","Land cover","CEC","Soil temperature","Soil pH","Absolute latitude",
                                "AP", "plant_PR","plant_SR","MAT","HFP","bacteria_PD"))+
  theme_void()+
  theme(legend.box = "horizontal",
        legend.position="bottom",
        legend.title = element_blank(),
        legend.key.width = unit(1.2, "cm"),
        legend.spacing.x = unit(0, "cm"),
        axis.title.x = element_blank(),
        axis.title.y = element_blank())+
  guides(fill = guide_legend(label.position = "bottom",nrow = 1,keywidth = 3,
                             keyheight = 1.2,legend.spacing.x= unit(1.5, "cm"),byrow = TRUE)) # 合并分类图例

map
ggsave(plot =map,
       here("output/figures/", "1007-spatial heterogeneity.pdf"),
       width = 18, height = 10.2)
