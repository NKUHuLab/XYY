library(caret)
library(readr)
library(readxl)
library(dplyr)

# 预测微生物的全球地图predict bacteria diversity ----------------------------------------------
func <- read.csv("pred_bacteria/Cfunctiongene.csv")
data<-func[complete.cases(func),]
diversity0<-readxl::read_xlsx('pred_bacteria/diversity.xlsx',4) 
dim(diversity0)
newdata<-diversity0[complete.cases(diversity0),]
diversity <-newdata %>% 
  as.data.frame() %>% 
  filter(land_cover %in% c("S","G","D","TF","BF","CF","C")) %>% 
  mutate(land_cover = factor(land_cover)) 
#sapply(diversity,class)
#char_cols <- sapply(diversity, is.character)
#diversity[char_cols] <- lapply(diversity[char_cols], function(x) suppressWarnings(as.numeric(as.character(x))))


factors <- c("Mean_Diurnal_Range","ET0"
             ,"Temperature_Seasonality","Precipitation_Seasonality"
             ,"MAT","AP"
             ,"Aridity","soil_temp"
             ,"Elevation"#,"ABS_latitude"
             ,"Bulk_Density"#,"Soil_age"
             ,"pH","CEC","NDVI","SOC","TN","TP"
             ,"Sand"
             ,"Clay"
             ,"land_cover","soil_temp")
model <- readRDS("derived/2023_rf_model_evenness.rds")
if(file.exists('derived//2023_rf_model_func_C.rds')){
  model2 <- readRDS("derived/2023_rf_model_func_C.rds")
} else {
  set.seed(3)
  train_index <- createDataPartition(data[["Col_sum"]], p=0.8, list=F)
  train_data <- data[,factors][train_index,] 
  train_data_group <- data[["Col_sum"]][train_index]
  test_data <- data[,factors][-train_index,] 
  test_data_group <- data[["Col_sum"]][-train_index]
  model2 <- train(x = train_data, 
                  y = train_data_group,
                  method = "rf",
                  importance = TRUE,
                  key=toString(500),
                  tuneGrid = expand.grid(mtry = c(4:15)),# length(predictors) or 2:6
                  trControl = trainControl(method = "cv", 
                                           number = 10,
                                           p = 0.8,
                                           savePredictions = TRUE))
  
  saveRDS(model2, here("derived/2023_rf_model_func_C.rds"))
}
model2
pred2 <- predict(model2,test_data) 
test_rmse <- RMSE(pred2,test_data_group,na.rm = TRUE)
test_R2 <- R2(pred2,test_data_group,formula = "corr",na.rm = FALSE)

model2$results %>% as_tibble %>% filter(mtry == model2$bestTune %>% unlist) %>% select(RMSE, Rsquared)
# variable importance
varImp(model2) %>% plot
varImp(model2, scale = FALSE) %>% plot

# xgboost -----------------------------------------------------------------
xgb_data <- data 
trainIndex <- createDataPartition(xgb_data$observed_features, p = .8, list = FALSE)
train <- xgb_data[trainIndex, ]
test <- xgb_data[-trainIndex, ]
caret_xgb_all <- train(observed_features~.,
                       data = xgb_data, 
                       method = "xgbTree",
                       importance = TRUE,
                       metric =  "Rsquared",
                       tuneGrid = expand.grid(
                         nrounds = 400,
                         eta = c(0.01, 0.1),
                         max_depth = c(2, 4),
                         gamma = 0,colsample_bytree=0.8, min_child_weight=2, subsample=1),
                       #tuneGrid = expand.grid(nrounds=500,max_depth=6,eta=0.0001,gamma=0.0,colsample_bytree=0.8, min_child_weight=2, subsample=1), 
                       # length(predictors) or 2:6
                       trControl = trainControl(method = "cv", 
                                                number = 10,
                                                p = 0.8,
                                                savePredictions = TRUE))
xgb_pred <- predict(caret_xgb_all,test)
xgb_test <- xgb_data[["observed_features"]][-trainIndex]
xgb_test_rmse <- RMSE(xgb_pred,xgb_test,na.rm = TRUE)
xgb_test_R2 <- R2(xgb_pred,xgb_test,formula = "corr",na.rm = FALSE)
# xgboost -----------------------------------------------------------------


all <- stack(map(factors, ~ get_static_raster(.x)))
names(all) <- factors

grid <- as.data.frame(all, xy = TRUE, na.rm = TRUE)
preddf <- grid %>%
  mutate(Aridity = Aridity/10000) %>%
  mutate(Sand = Sand/10) %>%
  mutate(Clay=Clay/10) %>%
  mutate(pH=pH/10) %>%
  mutate(Bulk_Density=Bulk_Density/100) %>%
  mutate(ABS_latitude = abs(y))

preddata <- preddf %>% 
  mutate(land_cover = glc_LC_num2chr(land_cover)) %>% 
  filter(land_cover %in% c("S","G","D","TF","BF","CF","C")) %>% 
  mutate(land_cover = factor(land_cover)) #remove unused levels
saveRDS(preddata, here("rds", "06-2-preddata-diversity.rds"))

mod<-model2
vars <- c("land_cover","Mean_Diurnal_Range","ET0"
          ,"Temperature_Seasonality","Precipitation_Seasonality","Annual_Mean_Temperature","Annual_Precipitation"
          ,"Aridity","soil_temp"
          ,"Elevation","ABS_latitude"
          ,"Bulk_Density","Soil_age"
          ,"pH","CEC"
          ,"Sand"
          ,"Clay")
predxy<-preddata[complete.cases(preddata),]
pred<-predxy %>% select(vars)
# predict from stack.as.df (~1min)
pred_result <- predict(mod, pred) %>% unname 
prediction<-cbind(predxy[1:2],pred_result) 
prediction <- prediction %>% mutate(pid = glc_pIDfromXY(x, y))%>% select(-c(x,y)) 
preddata <- preddata %>% mutate(pid = glc_pIDfromXY(x, y))

head(full)
head(preddata)
full <- full_join(prediction, preddata, by = "pid")
plot_data <- full %>% select(c(x,y,pred_result))
write.table(plot_data,file = "pred_bacteria_PD.csv", sep = ",", row.names = FALSE)
richness <- read.csv("pred_bacteria/pred_bacteria_richness.csv")
pd<-read.csv("pred_bacteria/pred_bacteria_shannon.csv")
my_colormap <- colorRampPalette(rev(brewer.pal(11,'Spectral')))(32)
map <- ggplot() + 
  geom_tile(data = pd, aes(x=x, y=y, fill=pred_result)) +
  borders(colour = NA, ylim = c(-60, 90))+
  coord_fixed(xlim = c(-180, 180), expand = FALSE)+
  scale_fill_gradientn(colours = my_colormap,na.value = "grey90",name="shannon_entropy")  +
  theme_void()+
  theme(
    plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 13.5),
    legend.title = element_text(face="bold",size=9),
    legend.direction = "horizontal",
    legend.position = c(0.65,0.05),
    legend.key.width = unit(0.8, "cm"),
    legend.key.height = unit(0.4,"cm")) +
  guides(fill=guide_coloursteps(title.position="top"))

#map
ggsave(paste0("pred_bacteria/","pred_shannons",".pdf"),map,device = "pdf", width = 20,
       height = 10.2,units = "cm",dpi = 1000)
# 导出raster文件 --------------------------------------------------------------
library(sp)
library(rgdal)
library(gstat)
coordinates(plot_data)=~x+y
proj4string(plot_data)=CRS("+proj=longlat +datum=WGS84 +no_defs") # set it to lat-long
plot_data = spTransform(plot_data,CRS("+proj=longlat +datum=WGS84 +no_defs"))
gridded(plot_data) = TRUE

r = raster(plot_data)
projection(r) = CRS("+proj=longlat +datum=WGS84 +no_defs")
plot(r)
r_interp <- raster::interpolate(r, method="bilinear")
library(gstat)
r_interp <- gstat::gstat(idw(plot_data ~ 1, locations = coordinates(r)), newdata = r, 
                         nmax = 10, set = list(idp = 2.0))

writeRaster(r,"bacteria_PD.tif")
r <- raster("bacteria_PD.tif")
print(r)
# 创建插值模型
vgm_model <- vgm(psill = 0.5, model = "Sph", range = 1000, nugget = 0.5)
#其中，psill表示变异程度，model表示插值模型，range表示空间相关距离，nugget表示块效应。

#执行插值：
# 对栅格文件进行插值
r_interp <- gstat::gstat.interpolate(r, gstat_model = vgm_model)
#马氏距离和AOA不做，直接导入数据预测

####################################################################################
vars <- c("observed_features","Mean_Diurnal_Range","ET0"
          ,"Temperature_Seasonality","Precipitation_Seasonality","Annual_Mean_Temperature","Annual_Precipitation"
          ,"Aridity","soil_temp"
          ,"Elevation","ABS_latitude"
          ,"Bulk_Density","Soil_age"
          ,"pH","CEC"
          ,"Sand"
          ,"Clay")
if(file.exists('derived//2023_rf_model_richness_ss.rds')){
  model2 <- readRDS("derived/2023_rf_model_richness_ss.rds")
} else {
  set.seed(3)
  train_index <- createDataPartition(diversity[["observed_features"]], p=0.8, list=F)
  train <- diversity[train_index,]
  test <- diversity[-trainIndex, ]
  preProcValues <- scale(train[,vars]) %>% as.data.frame() 
  train_data <- preProcValues[,factors] %>% mutate(land_cover= train$land_cover)
  train_data_group <- preProcValues[["observed_features"]]
  test_data <- test[,factors] %>% mutate(land_cover= test$land_cover)
  test_data_group <- test[["observed_features"]]
  
  model2 <- train(x = train_data, 
                  y = train_data_group,
                  method = "rf",
                  importance = TRUE,
                  key=toString(500),
                  tuneGrid = expand.grid(mtry = c(4:15)),# length(predictors) or 2:6
                  trControl = trainControl(method = "cv", 
                                           number = 10,
                                           p = 0.8,
                                           savePredictions = TRUE))
  
  saveRDS(model2, here("derived/2023_rf_model_richness_ss.rds"))
}
#################################################################################### 