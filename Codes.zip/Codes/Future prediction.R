###############################################################################
########################future prediction######################################
###############################################################################
# create prediction files
predictors <- model$trainingData %>% names %>% .[-length(.)]
vars
lc_levs <- levels(model$trainingData$Land_cover)

# Predictions all years ---------------------------------------------------
# predict, save df

cl <- makeCluster(15, outfile = "")
registerDoParallel(cl)

# 16 min with 6 cores, without saving raster
#
foreach(GCMs=c("ACCESS-CM2","CanESM5","IPSL-CM6A-LR","MIROC6","UKESM1-0-LL"),
        .packages = c("caret","dplyr","raster","here","magrittr","purrr","RColorBrewer","ggtext","foreach")) %dopar% {
          foreach(serino= c("ssp126","ssp245","ssp370","ssp585"),
                  .packages = c("caret","dplyr","raster","here","magrittr","purrr","RColorBrewer","ggtext","foreach")) %dopar% {
                    foreach (iyear = c("2021-2040","2041-2060","2061-2080","2081-2100"),
                             .packages = c("caret","dplyr","raster","here","magrittr","purrr","RColorBrewer","ggtext","foreach")) %dopar% {
                               source(here::here("get_prediction.R"))
                               st <- stack(map(vars, ~get_future_raster(.x, GCMs,serino,iyear)))
                               # rename
                               names(st) <- vars
                               grid <- as.data.frame(st, xy = TRUE, na.rm = TRUE)
                               #names(grid) <- c("x","y","Land_cover","MAT","MAP","aridity","soil_temp","HFP","elev","bd","soil_age","phh2o","cec", "difference","sand","clay" )
                               grid <- grid %>%
                                 dplyr::mutate(aridity = aridity/10000) %>%
                                 dplyr::mutate(sand = sand/10) %>%
                                 dplyr::mutate(clay=clay/10) %>%
                                 dplyr::mutate(phh2o=phh2o/10) %>%
                                 dplyr::mutate(soil_temp=soil_temp-273.15) %>%
                                 mutate(abs_latitude = abs(y))
                               # fix Land_cover col
                               grid <- grid %>% 
                                 dplyr::mutate(Land_cover = glc_LC_num2chr_future(Land_cover)) %>% 
                                 dplyr::filter(Land_cover %in% c("F","C","G","D")) %>% 
                                 dplyr::mutate(Land_cover = factor(Land_cover)) %>%
                                 dplyr::mutate(pid = glc_pIDfromXY(x, y))
                               
                               preddf<-readRDS("derived//06-2-preddf.rds") %>% dplyr::select(c("pid","Category"))
                               pred <- full_join(grid, preddf, by = "pid") 
                               preddata <- pred %>% 
                                 dplyr::filter(Category == "Predicted") %>%
                                 dplyr::select(-c("pid","Category")) %>%
                                 na.omit(preddata)
                               head(preddata)
                               #saveRDS(pred, here("rds/future/", paste0("06-2-grid-",GCMs,"_",serino,"_",iyear,".rds")))
                               all(names(preddata %>% dplyr::select(-c(x, y))) %in% names(model$trainingData))
                               
                               # predict from stack.as.df (~1min)
                               prediction <- predict(model, preddata %>% dplyr::select(-c(x, y))) %>% unname
                               predplot<-cbind(preddata[1:2],prediction)
                               predplot <- predplot %>% dplyr::mutate(pid = glc_pIDfromXY(x, y)) %>% dplyr::select(-c(x,y))
                               head(pred)
                               head(predplot)
                               full <- full_join(pred, predplot, by = "pid") 
                               prop <- prop.table(table(full$Land_cover))
                               F_prop <- prop["F"] %>% as.numeric() %>% round(.,3)
                               saveRDS(full, paste0("GCMs/full_",GCMs,"_",serino,"_",iyear,"_",F_prop,".rds"))
                               
                               # my_colormap <- colorRampPalette(rev(brewer.pal(11,'Spectral')))(32)
                               # map <- ggplot() + 
                               #   geom_tile(data = full, aes(x=x, y=y, fill=prediction)) +
                               #   borders(colour = NA, ylim = c(-60, 90))+
                               #   coord_fixed(xlim = c(-180, 180), expand = FALSE)+
                               #   scale_fill_gradientn(colours = my_colormap,na.value = "grey90",name="Ecosystem multifunctionality(Unitless)") +
                               #   labs(
                               #     title =iyear) +
                               #   theme_void()+
                               #   theme(
                               #     plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 13.5),
                               #     legend.title = element_text(face="bold",size=9),
                               #     legend.direction = "horizontal",
                               #     legend.position = c(0.65,0.05),
                               #     legend.key.width = unit(0.8, "cm"),
                               #     legend.key.height = unit(0.4,"cm")) +
                               #   guides(fill=guide_coloursteps(title.position="top"))
                               # 
                               # #map
                               # ggsave(paste0("output/future/","pred_",GCMs,serino,iyear,".pdf"),map,device = "pdf", width = 20,
                               #        height = 10.2,units = "cm",dpi = 1000)
                               
                             }
                  }
        }    

stopCluster(cl)


# only climate ------------------------------------------------------------

cl <- makeCluster(15, outfile = "")
registerDoParallel(cl)

# 16 min with 6 cores, without saving raster
#
foreach(GCMs=c("ACCESS-CM2","CanESM5","IPSL-CM6A-LR","MIROC6","UKESM1-0-LL"),
        .packages = c("caret","dplyr","raster","here","magrittr","purrr","RColorBrewer","ggtext","foreach")) %dopar% {
          foreach(serino= c("ssp126","ssp245","ssp370","ssp585"),
                  .packages = c("caret","dplyr","raster","here","magrittr","purrr","RColorBrewer","ggtext","foreach")) %dopar% {
                    foreach (iyear = c("2021-2040","2041-2060","2061-2080","2081-2100"),
                             .packages = c("caret","dplyr","raster","here","magrittr","purrr","RColorBrewer","ggtext","foreach")) %dopar% {
                               source(here::here("get_prediction.R"))
                               st <- stack(map(vars, ~get_future_climate(.x, GCMs,serino,iyear)))
                               # rename
                               names(st) <- vars
                               grid <- as.data.frame(st, xy = TRUE, na.rm = TRUE)
                               #names(grid) <- c("x","y","Land_cover","MAT","MAP","aridity","soil_temp","HFP","elev","bd","soil_age","phh2o","cec", "difference","sand","clay" )
                               grid <- grid %>%
                                 dplyr::mutate(aridity = aridity/10000) %>%
                                 dplyr::mutate(sand = sand/10) %>%
                                 dplyr::mutate(clay=clay/10) %>%
                                 dplyr::mutate(phh2o=phh2o/10) %>%
                                 dplyr::mutate(soil_temp=soil_temp-273.15) %>%
                                 mutate(abs_latitude = abs(y))
                               # fix Land_cover col
                               grid <- grid %>% 
                                 dplyr::mutate(Land_cover = glc_LC_num2chr_future(Land_cover)) %>% 
                                 dplyr::filter(Land_cover %in% c("F","C","G","D")) %>% 
                                 dplyr::mutate(Land_cover = factor(Land_cover)) %>%
                                 dplyr::mutate(pid = glc_pIDfromXY(x, y))
                               
                               preddf<-readRDS("derived//06-2-preddf.rds") %>% dplyr::select(c("pid","Category"))
                               pred <- full_join(grid, preddf, by = "pid") 
                               preddata <- pred %>% 
                                 dplyr::filter(Category == "Predicted") %>%
                                 dplyr::select(-c("pid","Category")) %>%
                                 na.omit(preddata)
                               head(preddata)
                               #saveRDS(pred, here("rds/future/", paste0("06-2-grid-",GCMs,"_",serino,"_",iyear,".rds")))
                               all(names(preddata %>% dplyr::select(-c(x, y))) %in% names(model$trainingData))
                               
                               # predict from stack.as.df (~1min)
                               prediction <- predict(model, preddata %>% dplyr::select(-c(x, y))) %>% unname
                               predplot<-cbind(preddata[1:2],prediction)
                               predplot <- predplot %>% dplyr::mutate(pid = glc_pIDfromXY(x, y)) %>% dplyr::select(-c(x,y))
                               head(pred)
                               head(predplot)
                               full <- full_join(pred, predplot, by = "pid") 
                               prop <- prop.table(table(full$Land_cover))
                               F_prop <- prop["F"] %>% as.numeric() %>% round(.,3)
                               saveRDS(full, paste0("GCMs/climate_",GCMs,"_",serino,"_",iyear,"_",F_prop,".rds"))
                             }
                  }
        }    

stopCluster(cl)


# only land cover change  -------------------------------------------------


cl <- makeCluster(15, outfile = "")
registerDoParallel(cl)
#
foreach(GCMs=c("ACCESS-CM2","CanESM5","IPSL-CM6A-LR","MIROC6","UKESM1-0-LL"),
        .packages = c("caret","dplyr","raster","here","magrittr","purrr","RColorBrewer","ggtext","foreach")) %dopar% {
          foreach(serino= c("ssp126","ssp245","ssp370","ssp585"),
                  .packages = c("caret","dplyr","raster","here","magrittr","purrr","RColorBrewer","ggtext","foreach")) %dopar% {
                    foreach (iyear = c("2021-2040","2041-2060","2061-2080","2081-2100"),
                             .packages = c("caret","dplyr","raster","here","magrittr","purrr","RColorBrewer","ggtext","foreach")) %dopar% {
                               source(here::here("get_prediction.R"))
                               st <- stack(map(vars, ~get_future_lui(.x, GCMs,serino,iyear)))
                               # rename
                               names(st) <- vars
                               grid <- as.data.frame(st, xy = TRUE, na.rm = TRUE)
                               #names(grid) <- c("x","y","Land_cover","MAT","MAP","aridity","soil_temp","HFP","elev","bd","soil_age","phh2o","cec", "difference","sand","clay" )
                               grid <- grid %>%
                                 dplyr::mutate(aridity = aridity/10000) %>%
                                 dplyr::mutate(sand = sand/10) %>%
                                 dplyr::mutate(clay=clay/10) %>%
                                 dplyr::mutate(phh2o=phh2o/10) %>%
                                 dplyr::mutate(soil_temp=soil_temp-273.15) %>%
                                 mutate(abs_latitude = abs(y))
                               # fix Land_cover col
                               grid <- grid %>% 
                                 dplyr::mutate(Land_cover = glc_LC_num2chr_future(Land_cover)) %>% 
                                 dplyr::filter(Land_cover %in% c("F","C","G","D")) %>% 
                                 dplyr::mutate(Land_cover = factor(Land_cover)) %>%
                                 dplyr::mutate(pid = glc_pIDfromXY(x, y))
                               
                               preddf<-readRDS("derived//06-2-preddf.rds") %>% dplyr::select(c("pid","Category"))
                               pred <- full_join(grid, preddf, by = "pid") 
                               preddata <- pred %>% 
                                 dplyr::filter(Category == "Predicted") %>%
                                 dplyr::select(-c("pid","Category")) %>%
                                 na.omit(preddata)
                               head(preddata)
                               #saveRDS(pred, here("rds/future/", paste0("06-2-grid-",GCMs,"_",serino,"_",iyear,".rds")))
                               all(names(preddata %>% dplyr::select(-c(x, y))) %in% names(model$trainingData))
                               
                               # predict from stack.as.df (~1min)
                               prediction <- predict(model, preddata %>% dplyr::select(-c(x, y))) %>% unname
                               predplot<-cbind(preddata[1:2],prediction)
                               predplot <- predplot %>% dplyr::mutate(pid = glc_pIDfromXY(x, y)) %>% dplyr::select(-c(x,y))
                               head(pred)
                               head(predplot)
                               full <- full_join(pred, predplot, by = "pid") 
                               prop <- prop.table(table(full$Land_cover))
                               F_prop <- prop["F"] %>% as.numeric() %>% round(.,3)
                               saveRDS(full, paste0("GCMs/lui_",GCMs,"_",serino,"_",iyear,"_",F_prop,".rds"))
                             }
                  }
        }    

stopCluster(cl)

# 定义新函数average将不同GCM模型得到的预测值进行平均 ------------------------------------------

for (pattern in c("ssp126_2021-2040","ssp126_2041-2060","ssp126_2061-2080","ssp126_2081-2100",
                  "ssp245_2021-2040","ssp245_2041-2060","ssp245_2061-2080","ssp245_2081-2100",
                  "ssp370_2021-2040","ssp370_2041-2060","ssp370_2061-2080","ssp370_2081-2100",
                  "ssp585_2021-2040","ssp585_2041-2060","ssp585_2061-2080","ssp585_2081-2100")){
  #pattern <- "i" 
  pred_files<- list.files(here("GCMs/.../"), pattern = ".rds", full.names =TRUE)
  # 定义正则表达式模式pattern <- "ssp126_2021-2040"
  # 从 `pred_files` 中筛选符合条件的文件
  filtered_files <- pred_files[grep(pattern, pred_files)]
  # 读取筛选后的文件并合并
  preds <- purrr::map_dfr(filtered_files, readRDS, .id = "year")
  pred2 <- preds %>% 
    dplyr::select(x, y, year, pid, prediction) %>% 
    nest(data = c(year, prediction)) %>% 
    dplyr::mutate(avg_prediction = purrr::map(data, ~mean(.x$prediction))) %>% 
    dplyr::select(-data) 
  pred2$avg_prediction <- sapply(pred2$avg_prediction, function(x) as.numeric(unlist(x)))
  pred2$prediction <- pred2$avg_prediction
  pred2$year <- 1
  saveRDS(pred2,here(paste0("GCMs/avg_...//mean_",pattern,".rds")))
}
#futurechangeplot <- list()
#barplot <- list()
#sumPlot <- list()
sumdata <- list()
bardata <- list()
serino <- c("xx","ssp126_2021-2040","ssp126_2081-2100",
            "ssp245_2021-2040","ssp245_2081-2100",
            "ssp370_2021-2040","ssp370_2081-2100",
            "ssp585_2021-2040","ssp585_2081-2100")
for (i in c(2:9)){
  seri <- serino[i]
  pred_files<- list.files(here("GCMs/avg_land_cover//"), pattern = ".rds", full.names =TRUE)
  preds <- map_dfr(pred_files[c(1,i)],readRDS, .id = "year")
  #preds <- map_dfr(pred_files,readRDS, .id = "year")
  preds$year <- as.numeric(preds$year) + 2017
  #删除prediction列中的空值
  preds <- preds %>% drop_na(prediction)
  pred2 <- preds  %>% dplyr::select(c(x,y,year,pid,prediction)) %>%  nest(data = c(year,prediction))
  change <- function(df, min_val = 2){
    n <- nrow(df)  
    if (n < min_val){
      diff <- NA
    } else {
      df <- df %>% as.data.frame()
      diff<-diff(df[,-1])
    }
    c(diff=diff)
  }
  dat1 <- pred2$data[[1]] %>% as.data.frame()
  nrow(dat1)
  diff(dat1[,-1])
  change(df = dat1)
  pred2 <- pred2 %>% 
    mutate(list = imap(data, ~ {if (.y %% 50000 == 0) cat(.y, "done\n");
      change(.x)} )) 
  #保留2018年的数据作为分母，计算变化百分数
  pred_diff <- pred2 %>% 
    mutate(diff = map_dbl(list,1)) %>% 
    unnest(cols = c(data, list)) %>%
    filter(year =="2018") %>%
    mutate(percent = diff/prediction*100) %>% 
    dplyr::select(-c(list))
  preddf<-readRDS("derived/06-2-preddf.rds")
  sumdata[[i]] <- full_join(pred_diff%>% dplyr::select(-c(x,y)), preddf , by = "pid")
  bardata[[i]] <- sumdata[[i]] %>% filter(Category == "Predicted")
  
  bardata[[i]] <- bardata[[i]]  %>% mutate(LST_diff= if_else(bardata[[i]]$difference > 15, 'LST_diff > 15', 'LST_diff <= 15'))
  bardata[[i]] <- bardata[[i]] %>% drop_na(percent)
}
saveRDS(sumdata,here(paste0("rds/sumdata_lui.rds")))
sumdata <- readRDS("rds/sumdata.rds")
for (i in c(...)){
  seri <- serino[i]
  my_colormap <- brewer.pal(11, 'PuOr')[c(2:4,7:11)]
  #my_colormap <- colorRampPalette(rev(brewer.pal(11,'Spectral')))(32)
  futurechangeplot[[i]] <- ggplot() +
    geom_tile(data = sumdata[[i]] %>% drop_na(percent), aes(x=x, y=y, fill=percent)) +
    borders(colour = 'black', fill = NA, ylim = c(-60, 90))+
    coord_fixed(xlim = c(-180, 180), expand = FALSE)+
    scale_fill_gradientn(colours = my_colormap,name="Percent of EMF change(%)",breaks = c(-Inf,-40, -20, -10, -5, 0, 5, 10, 20, 40,Inf)) +
    theme_bw() +
    theme(
      plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 50),
      legend.title = element_text(face="bold",size=40),
      legend.direction = "horizontal",
      legend.key.width = unit(10, "cm"),
      legend.key.height = unit(2.5,"cm"),
      panel.grid.major=element_line(colour=NA),
      panel.background = element_rect(fill = "transparent",colour = NA),
      plot.background = element_rect(fill = "transparent",colour = NA),
      panel.grid.minor = element_blank(),
      axis.title.x = element_blank(),
      axis.title.y =element_blank(),
      axis.text.x=element_blank(),
      axis.ticks.x=element_blank(),
      axis.text.y=element_blank(),
      axis.ticks.y=element_blank()
      
    ) +
    guides(
      fill = guide_coloursteps(
        title.position = "top",
        title.hjust = 0.5,
        keywidth = unit(2, "cm"),
        keyheight = unit(0.5, "cm"),
        label.theme = element_text(size = 30)
      )) 
  leg <- get_legend(futurechangeplot[[i]])
  futurechangeplot[[i]] <- futurechangeplot[[i]] + theme(legend.position = "none")
}
bardata <- readRDS("rds/bardata_lui.rds")
# 创建一个空的数据框用于存储提取的数据
data_extract <- data.frame()

# 循环提取数据并组合到新数据框中
#2020-2040--------------------------------
for (i in c(2, 4, 6, 8)) {
  if (i ==2) {
    group_name <- "SSP126"
  } else if (i == 4) {
    group_name <- "ssp245"
  } else if (i == 6) {
    group_name <- "ssp370"
  } else if (i == 8) {
    group_name <- "ssp585"
  }
  data <- bardata[[i]]
  extracted_data <- data[, c("LST_diff", "percent")]
  extracted_data$Group <- group_name
  data_extract <- rbind(data_extract, extracted_data)
}
# 循环提取数据并组合到新数据框中
# # 创建一个空的数据框用于存储提取的数据
# data_extract <- data.frame()
# 
# # 循环提取数据并组合到新数据框中
# for (i in c(3, 5, 7, 9)) {
#   if (i ==9) {
#     group_name <- "ssp585"
#   } else if (i == 7) {
#     group_name <- "ssp370"
#   } else if (i == 5) {
#     group_name <- "ssp245"
#   } else if (i == 3) {
#     group_name <- "SSP126"
#   }
#   
#   data <- bardata[[i]]
#   extracted_data <- data[, c("LST_diff", "percent")]
#   extracted_data$Group <- group_name
#   data_extract <- rbind(data_extract, extracted_data)
# }
# 使用 ggplot2 绘制分组箱线图
p <- ggplot(data_extract, aes(x = percent, y = Group, fill = LST_diff)) +
  geom_boxplot(outlier.shape = NA) +
  scale_fill_manual(values = c("#cab2d6",
                               "#b2df8a"))+
  xlim(-15,15)+
  labs(x="",y="")+
  theme_bw()+
  theme(plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 50),
        legend.title = element_blank(),
        legend.direction = "horizontal",
        legend.key.width = unit(10, "cm"),
        legend.key.height = unit(2.5,"cm"),
        axis.ticks.y = element_blank(),axis.text.y = element_blank())
leg <- get_legend(p)
ggsave("output/leg0728.png",leg,device="png",width = 10,height = 4)
data_extract <- read.csv("rds/2040_bardata.csv")
# write_csv(data_extract,"rds/2100_bardata.csv")
ggsave("output/figure7-b.pdf",device = "pdf",width = 5.7,height=10)

# 全球范围内不分温度不分区域 -----------------------------------------------------------

p <- ggplot(data_extract, aes(x = percent, fill = Group)) +
  geom_boxplot(outlier.shape = NA) +
  #scale_fill_manual(values = c("#FFB534"))+
  xlim(-20,20)+
  labs(x="",y="")+
  theme_bw()+
  theme(plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 12),
        #legend.title = element_blank(),
        legend.position = "",
        # legend.direction = "horizontal",
        # legend.key.width = unit(10, "cm"),
        # legend.key.height = unit(2.5,"cm"),
        axis.ticks.y = element_line(),
        #axis.text.y = element_text(size=10),
        #axis.text= element_blank()
  )
p
ggsave("output/figure7-a.pdf",device = "pdf",width = 5.7 ,height=10)

#only climate change or only land-use change or all change
bardata <- readRDS("rds/bardata.rds")
# bardata <- readRDS("rds/bardata_climate.rds")
# bardata <- readRDS("rds/bardata_lui.rds")
bardata <- readRDS("rds/bardata_lui.rds")
# 创建一个空的数据框用于存储提取的数据
data_extract <- data.frame()

# 循环提取数据并组合到新数据框中
#2020-2040
for (i in c(2, 8)) {
  if (i ==8) {
    group_name <- "ssp585-all"
  } else if (i == 2) {
    group_name <- "SSP126-all"
  }
  data <- bardata[[i]]
  extracted_data <- data[, c("ipbsr", "percent")]
  extracted_data$Group <- group_name
  data_extract <- rbind(data_extract, extracted_data)
}
#2080-2100
for (i in c(3, 9)) {
  if (i ==9) {
    group_name <- "ssp585-all"
  } else if (i == 3) {
    group_name <- "SSP126-all"
  }
  data <- bardata[[i]]
  extracted_data <- data[, c("ipbsr", "percent")]
  extracted_data$Group <- group_name
  data_extract <- rbind(data_extract, extracted_data)
}
p <- ggplot(data_extract, aes(x = percent, y = Group, fill = LST_diff)) +
  geom_boxplot(outlier.shape = NA) +
  scale_fill_manual(values = c("#cab2d6",
                               "#b2df8a"))+
  xlim(-15,15)+
  labs(x="",y="")+
  theme_bw()+
  theme(plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 50),
        legend.title = element_blank(),
        legend.direction = "horizontal",
        legend.key.width = unit(10, "cm"),
        legend.key.height = unit(2.5,"cm"),
        axis.ticks.y = element_blank(),axis.text.y = element_blank())
ggsave("output/2040bar.pdf",device = "pdf",width = 5.7,height=10)
#ggsave("output/2010bar.pdf",device = "pdf",width = 5.7,height=10)


