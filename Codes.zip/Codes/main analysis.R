library(raster)
library(tools)
library(sf)
library(tidyverse)
library(here)
library(doParallel)
library(foreach)
library(caret)
library(CAST)
library(cowplot)
library(grid)
library(gridExtra)
library(ggExtra)
library(forcats)
library(magick)
library(biscale)
library(gt)
library(tmap)
library(ggplot2)
library(ggthemes)
library(RColorBrewer)
library(bayestestR)
library(hrbrthemes)
library(ggtext)
library(showtext)
library(lmls)
# source functions from other script --------------------------
source(here::here("pred_functions.R"))

# figure dimensions and default theme
gg_width = 11
gg_height = 5.7
ggplot2::theme_set(ggplot2::theme_bw())

multi0<-readxl::read_xlsx('RF20230225_821.xlsx',3) 
dim(multi0)
newdata<-multi0[complete.cases(multi0),]
output <- data[, ncol(newdata)]
multi <-newdata %>% 
  as.data.frame() %>% 
  filter(Land_cover %in% c("F","C","G","D")) %>% 
  mutate(Land_cover = factor(Land_cover)) %>%
  filter(Topsoil== 1) 
write.csv(multi,file="training.csv",row.names = TRUE)
# training models --------------------------------------------------

predictors <- c("abs_latitude","Land_cover","MAT","MAP","aridity","soil_temp","HFP","elev"
                ,"phh2o" ,"cec"
                ,"difference"
                ,"sand","clay"
                ,"plant_SR","plant_PR"
                ,"bacteria_SR","bacteria_PD")
if(file.exists('derived//2023_rf_model.rds')){
  model <- readRDS("derived/2023_rf_model.rds")
} else {
  set.seed(1)
  train_index <- createDataPartition(multi[["EMF_mm"]], p=0.8, list=F)
  train_data <- multi[,predictors][train_index,]
  train_data_group <- multi[["EMF_mm"]][train_index]
  test_data <- multi[,predictors][-train_index,]
  test_data_group <- multi[["EMF_mm"]][-train_index]
  model <- train(x = train_data, 
                 y = train_data_group,
                 method = "rf",
                 importance = TRUE,
                 #key=toString(1000),
                 tuneGrid = expand.grid(mtry = c(4:15)),# length(predictors) or 2:6
                 trControl = trainControl(method = "cv", 
                                          number = 20,
                                          p = 0.8,
                                          savePredictions = TRUE))
  
  saveRDS(model, here("derived/2023_rf_model.rds"))
}
model
plot(model)
print(model)
print(model$finalModel)
print(model$trainingData)
pred <- predict(model,test_data)
test_rmse <- RMSE(pred,test_data_group,na.rm = TRUE)
test_R2 <- R2(pred,test_data_group,formula = "corr",na.rm = TRUE)
# RMSE + R2
model$results %>% as_tibble %>% filter(mtry == model$bestTune %>% unlist) %>% select(RMSE, Rsquared)
# variable importance
varImp(model) %>% plot
varImp(model, scale = FALSE) %>% plot


# overfit test ------------------------------------------------------------
permutation <- readxl::read_excel("0527-rpre.xlsx")
lm.model<-lm(permutation$q2~permutation$r2)
coef<-lm.model$coefficients
ggplot(data=permutation,aes(r2,q2))+
  geom_point(size=2.5,color='#00BFFF')+
  geom_abline(intercept=coef[1],slope=coef[2],size=1,color='black')+
  scale_x_continuous(limits=c(-1,1))+
  scale_y_continuous(limits=c(-5,1))+
  labs(title= 1)+
  coord_fixed(ratio=1/2)+
  theme_bw()+
  theme(axis.line=element_line(color='black'),
        axis.ticks.length=unit(0.3,'line'))+
  xlab(NULL)+
  ylab(NULL)+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
  annotate('text', x=0.2,y=1,label=paste0('intercept: ',round(coef[1],2)))
ggsave(here("output/figures", "permutation.pdf"), width = 12, height = 6)


# partial dependence analysis --------------------------------------------------------
library(randomForest)
library(pdp)
# pdp ---------------------------------------------------------------------
rf <- randomForest(multi$EMF_mm~., data = multi[,predictors], importance=TRUE,proximity=T,ntree=500,mtry=4,maxlocalImp = TRUE)

# Single factor partial dependence analysis -------------------------------
pdpplot <- list()
for (j in  1:16){
  var1 <- predictors[j]
  par<-pdp::partial(rf,pred.var = var1, chull = TRUE, progress = "text")
  label = c("EMF")
  ren_axis <- function(var) {
    
    tib <- tibble(var = c("Land_cover","abs_latitude","MAT","MAP", "aridity","soil_temp","HFP","elev","phh2o"
                          ,"cec","difference","sand","clay"        
                          , "plant_SR" , "plant_PR","bacteria_SR","bacteria_PD" ),
                  label = c("Land cover","Absolute latitude","Mean temperature (°C)","Annual Precipitation(mm)", "Aridity(Unitless)", "Soil Temperature(°C)","HFP","Elevation(m)","soil pH"
                            ,"CEC","LST_diff(°C)","Soil sand content(%)","Soil clay content(%)"        
                            , "Plant species richness" , "Plant phylogenetic richness","Soil bacterial richness","Soil bacterial faith’s pd"))
    #var = "MAT"
    lab <- tib$label[tib$var == var]
    if (length(lab) == 1) lab else "error"
  }
  pdpplot[[j]]<-local({
    par=par
    ggplot(par, aes(x = par[[1L]],
                    y = par[["yhat"]])) +
      geom_tile()+
      #geom_contour(color = 'white')+
      #viridis::scale_fill_viridis(name =label[1], option = 'D') +
      theme_bw()+
      xlab(ren_axis(v1))+
      ylab("Predicted EMF(Unitless)")+
      theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
      theme(axis.line=element_line(color='black'),axis.ticks.length=unit(0.3,'line')
            ,axis.title = element_text(size=18)
            ,axis.text = element_text(size=15)
            ,legend.title = element_text(size=15),
            legend.text = element_text(size=12))+
      theme(legend.position = c(0.85,0.73))
    #scale_x_continuous(limits = c(min(par$Zeta),60))
  })
  
  ggsave(paste0('output/pdpplot/',label[1],'-',var1,'.pdf'),width=4,height=4)
}


# Bivariate partial dependence analysis -----------------------------------

v1c=c(rep('difference',6),rep('aridity',3),rep('MAP',2),rep('phh2o',1))
v2c=c(rep("Land_cover",1),rep('aridity',2),rep('MAP',1),rep('phh2o',3),rep('MAP',1),rep('plant_PR',2))

netpdpplot<-list()
for (j in  1:10){
  v1<-v1c[j]
  v2<-v2c[j]
  par<-pdp::partial(rf,pred.var = c(v1,v2), chull = TRUE, progress = "text")
  label = c("EMF")
  ren_axis <- function(var) {
    
    tib <- tibble(var = c("Land_cover","abs_latitude","MAT","MAP", "aridity","soil_temp","HFP","elev","phh2o"
                          ,"cec","difference","sand","clay"        
                          , "plant_SR" , "plant_PR","bacteria_SR","bacteria_PD" ),
                  label = c("Land cover","Absolute latitude","Mean temperature (°C)","Annual Precipitation(mm)", "Aridity(Unitless)", "Soil Temperature(°C)","HFP","Elevation(m)","soil pH"
                            ,"CEC","LST_diff(°C)","Soil sand content(%)","Soil clay content(%)"        
                            , "Plant species richness" , "Plant phylogenetic richness","Soil bacterial richness","Soil bacterial faith’s pd"))
    #var = "MAT"
    lab <- tib$label[tib$var == var]
    if (length(lab) == 1) lab else "error"
  }
  netpdpplot[[j]]<-local({
    par=par
    ggplot(par, aes(x = par[[1L]], y = par[[2L]],
                    z = par[["yhat"]], fill = par[["yhat"]])) +
      geom_tile()+
      geom_contour(color = 'white')+
      viridis::scale_fill_viridis(name =label[1], option = 'D') +
      theme_bw()+
      xlab(ren_axis(v1))+
      ylab(ren_axis(v2))+
      theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
      theme(axis.line=element_line(color='black'),axis.ticks.length=unit(0.3,'line')
            ,axis.title = element_text(size=18)
            ,axis.text = element_text(size=15)
            ,legend.title = element_text(size=15),
            legend.text = element_text(size=12))+
      theme(legend.position = c(0.85,0.73))
    #scale_x_continuous(limits = c(min(par$Zeta),60))
  })
  
  ggsave(paste0('output/pdpplot/',label[1],'-',v1,'-',v2,'.pdf'),width=4,height=4)
}

## Partial dependance plots--under different land use type -----------------------------------------------

# prep --------------------------------------------------------------------

range_df <- readRDS(here("derived/07-pred_dataset_all_years.rds"))
lc_lvls <- model$trainingData %>% pull(Land_cover) %>% levels# is similar to $


lc_labs <- glc_Land_cover_classes()[c(1,3)] %>% mutate(class = str_to_sentence(class)) %>% pull(2,1)

col_val <- c("F" = "#379237",
             "G" ="#82CD47",
             "C" = "#F7DB6A",
             "D" = "#C8B6A6")
#"S" = "#f8cbad",
#"G" = "#f4b084",

# fct ---------------------------------------------------------------------
ren_axis <- function(var) {
  
  tib <- tibble(var = c("abs_latitude","MAT","MAP", "aridity","soil_temp","HFP","elev","phh2o"
                        ,"cec","difference","sand","clay"        
                        , "plant_SR" , "plant_PR","bacteria_SR","bacteria_PD" ),
                label = c("Absolute latitude","Mean temperature (°C)","Annual Precipitation(mm)", "Aridity(Unitless)", "Soil Temperature(°C)","HFP","Elevation(m)","soil pH"
                          ,"CEC","LST_diff(°C)","Soil sand content(%)","Soil clay content(%)"        
                          , "Plant species richness" , "Plant phylogenetic richness","Soil bacterial richness","Soil bacterial phylogenetic diversity"))
  #var = "MAT"
  lab <- tib$label[tib$var == var]
  
  if (length(lab) == 1) lab else "error"
  
}


# do work -----------------------------------------------------------------

# function to make plot for variable, one line per LC
train_data0 <- model$trainingData
train_data <- train_data0 %>% .[-length(.)]
predictors_num <- train_data %>% select(-Land_cover) %>% names 

# default range from training data
# use median values from training data
glc_pdp <- function(xvar, model = model, range_df = NULL, npts = 100) {
  tr_sp <- train_data %>%
    group_split(Land_cover) %>%
    set_names(levels(train_data$Land_cover))
  
  # create dataset for each land cover
  lvl_lc <- levels(train_data$Land_cover)
  
  mk_pr_df <- function(dat) {
    # dat <- tr_sp[[1]]
    
    lc1 <- dat$Land_cover %>% unique
    stopifnot(length(lc1) == 1)
    
    # xvals
    if (is.null(range_df)) {
      xrange <- range(dat[xvar])
      
    } else {
      xrange <- range_df %>% 
        filter(Land_cover == lc1) %>%
        pull(all_of(xvar)) %>% 
        range(na.rm = TRUE)
      
    }
    #seq(0, 1, length.out = 11)
    xvals <- seq(from = xrange[1], to = xrange[2], length.out = npts)
    
    # medians
    meds <- dat %>% select(-c(Land_cover, all_of(xvar))) %>% map_dbl(median, na.rm = TRUE)
    
    prdf <- tibble(xvals = xvals,
                   Land_cover = lc1) %>% 
      bind_cols(meds %>% bind_rows) #meds %>% as.list %>% as_tibble # or tibble(!!!meds)
    
    names(prdf)[1] <- xvar
    
    prdf
    
  }
  
  to_predict <- map_dfr(tr_sp, mk_pr_df)
  
  preds <- to_predict %>% mutate(predicted = predict(model, to_predict))
  
  p <- ggplot(preds, aes_string(xvar, "predicted", color = "Land_cover"))+
    
    (data = train_data0, aes(y = .outcome), alpha = 0.4, fill = NA)+
    geom_line(size = 1)+
    ylim(0, NA)+ #270 for curves only
    labs(x =ren_axis(xvar),
         y = NULL,
         color = "Land-cover type")+
    scale_color_manual(values = col_val,
                       labels = lc_labs)
  
  if (!exists("leg")) leg <<- get_legend(p)
  # ggdraw(leg)
  leg <- get_legend(p)
  p <- p + theme(legend.position = "none")
} 
plots <- map(predictors_num, glc_pdp)
plots
# 5x2 display 
all_grid <- plot_grid(plot_grid(plotlist = plots[c(1,2,5,6,7,9,11,12,13,15,16)], ncol =3),
                      plot_grid(leg, ncol = 3),
                      ncol = 1, rel_heights=c(4, 1))
all_grid <- plot_grid(
  plot_grid(plotlist = plots[c(10,4,3)], ncol = 3),
  plot_grid(plots[[8]], plots[[14]], leg, ncol = 3),
  ncol = 1, rel_heights = c(1, 1)
)

all_grid
# for common y axis
y.grob <- textGrob("Predicted EMF (Unitless)", 
                   gp=gpar(fontsize=11),
                   rot=90)

main_final <- plot_grid(y.grob, all_grid, rel_widths = c(0.05, 0.95))
main_final

ggsave(plot = main_final,
       here("output/figures", "11-5-partial_dependence_plots.pdf"),dpi = 300,width = 6.5,height = 4)





# figure S1---------------------------------------------------------------

# ------- Environmental coverage analysis (06-2,3) -----------

## Mahalanobis distance --------------------------------------

### world grid -------------------------------------------------------------

# no LC\
vars <- c(#"Land_cover",
  "MAT","MAP","aridity","soil_temp","HFP","elev"#,"bd", "soil_age"
  ,"phh2o" ,"cec"
  #,"LSTd","LSTn"
  ,"difference"
  ,"sand","clay"
  ,"plant_SR","plant_PR"
  ,"bacteria_SR","bacteria_PD")
#,"mammals","amphibians"
# stack all layers

all <- stack(map(vars, ~glc_get_nolandcover(.x)))
names(all) <- vars
grid <- as.data.frame(all, xy = TRUE, na.rm = TRUE)
grid <- grid %>%
  mutate(aridity = aridity/10000) %>%
  mutate(sand = sand/10) %>%
  mutate(clay=clay/10) %>%
  mutate(phh2o=phh2o/10) %>%
  #mutate(bd=bd/100) %>%
  mutate(plant_PR=plant_PR*10) %>%
  mutate(abs_laitude = abs(y))
head(grid)
saveRDS(grid, here("rds", "06-2-grid-nolc.rds"))
grid <- readRDS(here("rds", "06-2-grid-nolc.rds"))
# maha multi
multi[] <- lapply(multi, as.numeric)
sapply (multi, class)
maha_multi <- mahadist(dat = multi, world = grid, vars = vars, xy = c("x", "y"))

#筛选出大于97.5的经纬度
saveRDS(maha_multi,here("rds", "06-2-maha_object.rds"))
mahamask 
maha_multi <- readRDS(here("rds", "06-2-maha_object.rds"))

mahamask <- maha_multi %>% filter(mahatype == ">0.975(Outliers)") %>% select(x, y)
# figure
ggplot(maha_multi, aes(x, y, fill = mahatype))+
  borders(fill = "grey90", colour = NA, ylim = c(-60, 90))+
  geom_tile(key_glyph = "polygon3")+
  coord_fixed(xlim = c(-180, 180), expand = TRUE)+
  scale_fill_manual(values = c("<0.50" = "#6A9FBF",
                               "0.50-0.75" = "#53AD9C",
                               "0.75-0.975" = "#E6B075",
                               ">0.975(Outliers)" = "#FCD3B2"),
                    name = "Quantile distribution")+
  theme_void()+
  theme(legend.position = c(0.1, 0.18),
        legend.text = element_text(size=15),
        legend.title = element_text(size=18,face = "bold"),
        legend.key = element_rect(linewidth = 13, fill = "white", colour = NA), # didn't work
        legend.key.width = unit(1.5, "cm"),
        legend.key.height = unit(1.3, "cm")
  ) +
  annotate("text", -Inf, Inf, hjust = -0.8, vjust = 1.5, label = "A", size = 20/.pt,
           fontface = "bold")

ggsave(here("output/figures", "05-maha_quant_suppFig.tiff"),
       width = gg_width, height = gg_height)

ggsave(here("output/figures", "08-maha_quant_suppFig.pdf"),
       width = 18, height = 10.2)


predictors<- c("Land_cover","MAT","MAP","aridity","soil_temp","HFP","elev"#,"bd", "soil_age"
               ,"phh2o" ,"cec"
               #,"LSTd","LSTn"
               ,"difference"
               ,"sand","clay"
               ,"plant_SR","plant_PR"
               ,"bacteria_SR","bacteria_PD")
#          ,"mammals","amphibians"

# # stack all layers ------------------------------------------------------


st <- stack(map(predictors, ~glc_get_raster(.x)))
names(st) <- predictors
# pred --------------------------------------------------------------------
mod<-model
preddf <- as.data.frame(st, xy = TRUE, na.rm = TRUE)

all(names(preddf %>% select(-c(x, y))) %in% names(mod$trainingData))
#fix 数量???
preddf <- preddf %>%
  mutate(aridity = aridity/10000) %>%
  mutate(sand = sand/10) %>%
  mutate(clay=clay/10) %>%
  mutate(phh2o=phh2o/10) %>%
  #mutate(bd=bd/100)
  mutate(plant_PR=plant_PR*10) %>%
  mutate(abs_latitude = abs(y))
# fix Land_cover col
preddf <- preddf %>% 
  mutate(Land_cover = glc_LC_num2chr(Land_cover)) %>% 
  filter(Land_cover %in% c("F","C","G","D")) %>% 
  mutate(Land_cover = factor(Land_cover)) #remove unused levels
#preddf <- preddf %>% select(-c(x,y))

# predict from stack.as.df (~1min)


## Area of applicability ----------------------------------------------------

rmse <- function(pred,obs){sqrt( mean((pred - obs)^2, na.rm = TRUE) )}

# multi

multi # as.data.frame needed to avoid issues with tibble in CAST

### aoa calculation ---------------------------------------------------------

cl <- makeCluster(10) #8-10
registerDoParallel(cl)

# with variable weighting: (~5-10 min)
AOA <- aoa(preddf, model = mod)

# AOA$AOA %>% table
# attributes(AOA)$aoa_stats
saveRDS(AOA, here("rds", "06-2-AOA_object.rds"))

stopCluster(cl)


## put together ------------------------------------------------------------

preds <- mod$pred[mod$pred$mtry==mod$bestTune$mtry,]#保留最好参数的结果

absError <- abs(preds$pred[order(preds$rowIndex)]-preds$obs[order(preds$rowIndex)])

preddf <- preddf %>% mutate(DI = AOA$DI,
                            AOA = AOA$AOA)
saveRDS(preddf,here("rds","06-2-preddf_aoa.rds"))

### figure suppl ------------------------------------------------------------

thr_stats <- attributes(AOA)$aoa_stats$threshold_stats
thresh <- AOA$parameters$threshold
pfig <- preddf %>%
  dplyr::mutate(di_quant = factor(case_when(
    DI > thresh ~ ">0.95 (Outliers)",
    DI > thresh*(0.75/0.95) ~ "0.75-0.95",
    DI > thresh*(0.5/0.95) ~ "0.50-0.75",
    TRUE ~ "<0.50"), 
    levels = c("<0.50", "0.50-0.75", "0.75-0.95", ">0.95 (Outliers)"))
  )

saveRDS(pfig,here("derived/06-2-AOA_pfig.rds"))
pfig <- readRDS(here("derived/06-2-AOA_pfig.rds"))
ggplot(pfig, aes(x, y, fill = di_quant))+
  borders(fill = "grey90", colour = NA, ylim = c(-60, 90))+
  geom_tile(key_glyph = "polygon3")+
  coord_fixed(xlim = c(-180, 180), expand = FALSE)+
  scale_fill_manual(values = c("<0.50" = "#0c1079ff",
                               "0.50-0.75" = "#1b93abff",
                               "0.75-0.95" = "#38df09ff",
                               ">0.95 (Outliers)" = "#fea77fff"),
                    name = "Quantile distribution")+
  theme_void()+
  theme(legend.position = c(0.1, 0.18),
        legend.text = element_text(size=15),
        legend.title = element_text(size=18,face = "bold"),
        legend.key = element_rect(linewidth = 13, fill = "white", colour = NA), # didn't work
        legend.key.width = unit(1.5, "cm"),
        legend.key.height = unit(1.3, "cm")
  )+
  annotate("text", -Inf, Inf, hjust = -0.8, vjust = 1.5, label = "B", size =20/.pt,
           fontface = "bold")

ggsave(here("output/figures", "06-2-AOA_quant_suppFig.png"),
       width = gg_width, height = gg_height)
ggsave(here("output/figures", "08-aoa_pred_masks.pdf"),
       width = 18, height = 10.2)

#### Plot results:
grid.arrange(spplot(AOA$DI,col.regions=viridis(100),main="DI with sampling locations (red)")+
               spplot(as_Spatial(pts),zcol="ID",col.regions="red"),
             spplot(prediction, col.regions=viridis(100),
                    main="prediction for AOA \n(LOOCV error applies)")
             + spplot(AOA$AOA,col.regions=c("grey","transparent")),ncol=2)

## Create mask

preddf
#AOA
aoamask <- preddf %>% filter(AOA == 0) %>% select(x, y)
aoamask$aoam <- 1
aoamask <- aoamask %>% mutate(pid = glc_pIDfromXY(x, y)) %>% 
  select(-c(x,y))
saveRDS(aoamask,here("rds","aoamask.rds"))
#sum(!aoa_df$AOA) == nrow(aoamask)


# mahalanobis mask
mahamask
mahamask$maham <- 1
mahamask <- mahamask %>% mutate(pid = glc_pIDfromXY(x, y)) %>% 
  select(-c(x,y))
saveRDS(mahamask,here("rds","mahamask.rds"))
head(aoamask)
head(mahamask)


# combine masks
fullmask <- full_join(aoamask, mahamask, by = "pid")

fullmask <- fullmask %>% select(pid, maha_mask = maham, aoa_mask = aoam) %>% 
  mutate(mask = 1) # as.numeric(maha_mask | aoa_mask)
#
saveRDS(fullmask, here("rds", "06-3-fullmask_df.rds"))
fullmask <- readRDS( here("rds", "06-3-fullmask_df.rds"))
head(fullmask)


### plot 可预测范围--------------------------------------------------------------------

preddf <- preddf %>% mutate(pid = glc_pIDfromXY(x, y)) %>% 
  left_join(fullmask, by = "pid")

preddf %>% names

sum(preddf$maha_mask == 1, na.rm = TRUE)
sum(preddf$aoa_mask == 1, na.rm = TRUE)

# Compare both
preddf <- preddf %>% mutate(Category = case_when(
  maha_mask == 1 & aoa_mask == 1 ~ "Outlier with both methods",
  maha_mask == 1 ~ "Mahalanobis outlier",
  aoa_mask == 1 ~ "Area of applicability outlier",
  TRUE ~ "Predicted"
) %>% factor(levels = c("Mahalanobis outlier", "Area of applicability outlier",
                        "Outlier with both methods", "Predicted", "Deficient data")))

preddf %>% count(Category)
# Category      n
# 1           Mahalanobis outlier 175600
# 2 Area of applicability outlier 376730
# 3     Outlier with both methods 407915
# 4                     Predicted 990859
saveRDS(preddf,here("derived", "06-2-preddf.rds"))
preddf <- readRDS(here("derived/", "06-2-preddf.rds"))
#cmic <- glc_proc_data()
str(multi)
multi<-multi[c("Land_cover","MAT","MAP","aridity","soil_temp","HFP","elev","bd", "soil_age"
               ,"phh2o" ,"cec" ,"difference","sand","clay","lat","long")] %>% mutate(long= as.numeric(multi$long))
# need to separate legend
multi$long <- as.numeric(multi$long)
ggplot(preddf, aes(x, y, fill = Category))+
  borders(size = 0.3, fill = "grey90", ylim = c(-60, 90), colour = NA,
          show.legend = TRUE)+
  geom_raster(alpha = 0.7)+
  # borders(size = 0.3, fill = NA, ylim = c(-60, 90))+
  scale_fill_manual(values = c("Mahalanobis outlier" = "#2a7fff",
                               "Area of applicability outlier" = "#ff4a4a",
                               "Outlier with both methods" = "#cc78df",
                               "Predicted" = "#8ef284",
                               "Deficient data" = "grey90"),
                    drop = FALSE)+
  geom_point(data = multi, aes(x = long,y = lat), 
             size = 1, inherit.aes = F, shape = 1, alpha = 0.5)+
  theme_void()+
  theme(
    legend.position = c(0.1, 0.18),
    legend.title = element_text(face = "bold"))+
  coord_fixed()+
  annotate("text", -Inf, Inf, hjust = -0.5, vjust = 1.5, label = "C", size = 16/.pt,
           fontface = "bold")

ggsave(here("output/figures", "predicted_masks.pdf"),
       width = 18, height = 10.2)

(p_mask <- ggplot(preddf %>% filter(Category == "Predicted"), aes(x, y, fill = Land_cover))+
    borders(size = 0.3, fill = "grey90", ylim = c(-60, 90), colour = NA,
            show.legend = TRUE)+
    geom_raster(alpha = 0.7)+
    scale_fill_manual(values = c("F" = "#379237",
                                 "G" ="#82CD47",
                                 "C" = "#F7DB6A",
                                 "D" = "#C8B6A6")
                      # ,labels = c("Forest", "Grassland","Cropland", "Sparse/no vegetation")
                      ,drop = FALSE)+
    geom_point(data = multi, aes(x = long,y = lat), 
               size = 1, inherit.aes = F, shape = 1, alpha = 0.5)+
    theme_void()+
    theme(
      # legend.position = c(0.1, 0.2),
      legend.title = element_text(face = "bold"))+
    coord_fixed())


p_mask_noleg <- p_mask +
  theme(legend.position = "none")

leg_pt <- get_legend(ggplot(mtcars %>% mutate(col = "Sampling site"), aes(wt, mpg, color = col)) +
                       geom_point(shape = 1.5)+
                       scale_color_manual(values = "black", name = NULL)+
                       theme(legend.justification = c(-0.011,1)))

ggdraw(leg_pt)

leg1 <- get_legend(p_mask +
                     scale_fill_manual(values = c("F" = "#379237",
                                                  "G" ="#82CD47",
                                                  "C" = "#F7DB6A",
                                                  "D" = "#C8B6A6"),
                                       labels = c("Cropland", "Sparse/no vegetation","Forest", "Grassland"),
                                       drop = FALSE)+
                     labs(fill = "Predicted")+
                     theme(legend.justification = c(0,1)))
ggdraw(leg1)

lc_tags <- tibble(lc_code = c("D", "C", "F", "G"),
                  lc_full = c("Sparse/no vegetation", "Cropland", "Forest","Grassland"))

lc_count <- multi %>% count(Land_cover) %>% mutate(Land_cover = factor(Land_cover)) %>%
  left_join(lc_tags, by = c("Land_cover" = "lc_code"))

lc_count %>% pull(lc_full)

fct_ord <- lc_count %>% arrange(desc(n)) %>% pull(lc_full)
lc_count <- lc_count %>% mutate(lc_full = factor(lc_full, levels = fct_ord))

# removed colors for clarity
fill_val <- c("Cropland" = "#F7DB6A",
              "Sparse/no vegetation"=  "#C8B6A6",
              "Forest" =  "#379237",
              "Grassland" = "#82CD47"
)

(lcb1 <- ggplot(lc_count, aes(n, lc_full, fill = lc_full)) +
    geom_col(orientation = "y", show.legend = FALSE, fill = "grey20") +
    scale_fill_manual(values = fill_val)+
    xlab("Number of samples")+
    theme_classic() +
    theme(axis.title.y = element_blank(),
          plot.background = element_blank(),
          panel.background = element_blank()))

(finalPlot <- ggdraw(p_mask_noleg) +
    draw_plot(lcb1, 0.58, 0.1, 0.24, 0.24)+
    draw_plot(leg_pt, 0.055, 0.42, 0.2, 0.06, hjust = 0)
  +draw_plot(leg1, 0.06, 0.12, 0.2, 0.3, hjust = 0, halign = -1)
)
plot(finalPlot)
ggsave(plot = finalPlot,
       here("output/figures", "06-3-Figure_0523_masks.pdf"),
       width = 18, height = 10.2)
ggsave("output/figures/06-3-Figure_0309_masks.tif",plot=finalPlot,device = "tiff",width = 18,height = 10.2,units = "cm")

# 

# PREDICT 2007-2018 -------------------------------------------------------


vars <- c("Land_cover","MAT","MAP","aridity","soil_temp","HFP","elev"
          ,"phh2o" ,"cec"
          ,"difference"
          ,"sand","clay"#,"abs_latitude"
          ,"plant_SR","plant_PR"
          ,"bacteria_SR","bacteria_PD")
#mask<- readRDS("rds//06-3-fullmask_df.rds")

#done-----------------------------------
for (i in c(2007:2018)){
  all <- stack(map(vars, ~get_resample_raster(.x, i)))
  names(all) <- vars
  grid <- as.data.frame(all, xy = TRUE, na.rm = TRUE)
  
  grid <- grid %>%
    mutate(aridity = aridity/10000) %>%
    mutate(sand = sand/10) %>%
    mutate(clay=clay/10) %>%
    mutate(phh2o=phh2o/10) %>%
    #mutate(bd=bd/100) %>%
    mutate(soil_temp=soil_temp-273.15) %>%
    mutate(abs_latitude = abs(y))
  # fix Land_cover col
  grid <- grid %>% 
    mutate(Land_cover = glc_LC_num2chr_future(Land_cover)) %>% 
    filter(Land_cover %in% c("F","C","G","D")) %>% 
    mutate(Land_cover = factor(Land_cover)) %>%
    mutate(pid = glc_pIDfromXY(x, y))
  preddf<-readRDS("derived//06-2-preddf.rds") %>% select(c("pid","Category"))
  pred <- full_join(grid, preddf, by = "pid") 
  preddata <- pred %>% 
    filter(Category == "Predicted") %>%
    select(-c("pid","Category")) %>%
    na.omit(preddata)
  head(preddata)
  all(names(preddata %>% select(-c(x, y))) %in% names(model$trainingData))
  
  # predict from stack.as.df (~1min)
  prediction <- predict(model, preddata %>% select(-c(x, y))) %>% unname
  predplot<-cbind(preddata[1:2],prediction)
  predplot <- predplot %>% mutate(pid = glc_pIDfromXY(x, y)) %>% select(-c(x,y))
  head(pred)
  head(predplot)
  #conflicts_prefer(parallel::stopCluster)
  full <- full_join(pred, predplot, by = "pid") 
  head(full)
  saveRDS(full, paste0("eachyear/0524_full_",i,".rds"))
  my_colormap <- colorRampPalette(rev(brewer.pal(11,'Spectral')))(32)
  map <- ggplot() +
    geom_tile(data = full, aes(x=x, y=y, fill=prediction)) +
    borders(colour = NA, ylim = c(-60, 90))+
    coord_fixed(xlim = c(-180, 180), expand = FALSE)+
    scale_fill_gradientn(colours = my_colormap,na.value = "grey90",name="Ecosystem multifunctionality(Unitless)") +
    labs(
      title =i) +
    theme_void()+
    theme(
      plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 13.5),
      legend.title = element_text(face="bold",size=9),
      legend.direction = "horizontal",
      legend.position = c(0.65,0.05),
      legend.key.width = unit(0.8, "cm"),
      legend.key.height = unit(0.4,"cm")) +
    guides(fill=guide_coloursteps(title.position="top"))
  
  map 
  ggsave(paste0("output/eachyear/","0524_pred_",i,".pdf"),map,device = "pdf", width = 20,
       height = 10.2,units = "cm",dpi = 1000)
}

# 2018年数据按照分区导出 -----------------------------------------------------------
# regional analysis -----------------------------------------------------
ipras <- raster(here("geodata", "09-ipbes_subregions_alphaOrder.tif"))
names(ipras) <- "ipbco"

levs <- c("Antarctica", "Caribbean", "Central Africa", "Central and Western Europe", 
          "Central Asia", "East Africa and adjacent islands", "Eastern Europe", 
          "Mesoamerica", "North-East Asia", "North Africa", "North America", 
          "Oceania", "South-East Asia", "South America", "South Asia", 
          "Southern Africa", "West Africa", "Western Asia")
#不同区域对应编码
match_tbl <- tibble(ipbsr = levs,
                    code = 1:length(ipbsr))
pred_2018 <- readRDS("eachyear/0524_full_2018.rds")
ip_df <- as.data.frame(ipras, xy = TRUE, na.rm = TRUE)
ip_df <- ip_df %>% 
  left_join(match_tbl, by = c("ipbco" = "code")) %>% 
  mutate(pid = glc_pIDfromXY(x, y)) %>% 
  dplyr::select(-c(x,y))
pred <- full_join(pred_2018,ip_df,by = "pid")
pred <- pred %>% drop_na(ipbsr)
p <- ggplot(pred, aes(x = prediction, y = ipbsr)) +
  geom_boxplot(outlier.shape = NA,fill = "#F4D160") +
  #scale_fill_manual(values ="#cab2d6")+
  xlim(0,0.4)+
  labs(x="Predicted EMF(Unitless)")+
  theme_bw()+
  theme(plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 50),
        legend.title = element_blank(),
        legend.direction = "horizontal",
        legend.key.width = unit(10, "cm"),
        legend.key.height = unit(2.5,"cm"),
        axis.title.y = element_blank(),
        axis.text.y = element_text(size=8),
        axis.text.x = element_text(size=6))
p
ggsave("output/2018-ipbsr_bar.pdf",device = "pdf",width = 5.7,height=6)

#uncertainty -------------------------------------------------------------
# Prediction intervals for 2018 with 100 runs


lc_levs <- levels(multi$Land_cover)

# global layers
st2018 <- stack(map(vars, ~get_resample_raster(.x, 2018)))
names(st2018) <- vars

gridyear <- as.data.frame(st2018, xy = TRUE, na.rm = TRUE)
gridyear <- gridyear %>% mutate(pid = glc_pIDfromXY(x, y)) # similar to cellFromXY()

# LC to text
gridyear <- gridyear %>%
  mutate(Land_cover = glc_LC_num2chr(Land_cover)) %>%
  filter(Land_cover %in% lc_levs) %>%
  mutate(Land_cover = factor(Land_cover))

# mask
fullmask <- readRDS( here("rds", "06-3-fullmask_df.rds"))

fullmask <- fullmask %>% select(pid, mask)
#
gridyear <- gridyear %>% left_join(fullmask, by = "pid") %>%
  filter(is.na(mask)) %>% select(-mask)


# fct to run RF
make_pred_2018 <- function() {
  cat("\n     starting")
  train_index <- createDataPartition(multi[["EMF_mm"]], p=0.8, list=F)
  train_data <- multi[,predictors][train_index,]
  train_data_group <- multi[["EMF_mm"]][train_index]
  test_data <- multi[,predictors][-train_index,]
  test_data_group <- multi[["EMF_mm"]][-train_index]
  model <- train(x = train_data, 
                 y = train_data_group,
                 method = "rf",
                 importance = TRUE,
                 #key=toString(1000),
                 tuneGrid = expand.grid(mtry = c(4:6)),# length(predictors) or 2:6
                 trControl = trainControl(method = "cv", 
                                          number = 10,
                                          p = 0.8,
                                          savePredictions = TRUE))
  cat("\n    training done")
  # predict (100 sec)
  is.data.frame(preddata)
  topred <- preddata %>% dplyr::select(-c(x,y))
  gridpred <- preddata %>%  dplyr::mutate(pred=predict(model, topred ))
  cat("\n        predict done")
  # save raster
  df_ras <- gridpred %>%  dplyr::select(x, y, pred)
  p_ras <- rasterFromXYZ(df_ras)
  crs(p_ras) <- crs(st2018)
  p_ras2 <- extend(p_ras, st2018)
  
  writeRaster(p_ras2, here("derived", "06-7-RF_runs",
                           paste0("One_run_2018_", ii, ".tif")),overwrite=TRUE)
  
  cat("\n            full run done")
  
}


#devtools::install_github("r-lib/conflicted")
library(conflicted)
conflicts_prefer(data.table::first)
conflicts_prefer(dplyr::select)
conflict_prefer("filter", "dplyr")
conflict_prefer("select", "dplyr")
conflicts_prefer(raster::area)
conflict_scout()
#调用最初的multi 
# Requires a multi-core cluster
cl <- makeCluster(10, outfile = "")
registerDoParallel(cl)
clusterCall(cl, function() library(magrittr))
foreach(ii = 1:100, .packages = c("caret","dplyr","raster","here")) %dopar% {
  
  source(here::here("get_prediction.R"))
  make_pred_2018()
  
}
stopCluster(cl)



## calculate stocks --------------------------------------------------------------
conflicts_prefer(dplyr::between)
st1 <- stack(list.files(here("derived/06-7-RF_runs"), 
                        pattern = "\\.tif$", full.names = TRUE))


## SD and plot -------------------------------------------------------------

pred_sd <- calc(st1, sd, na.rm = TRUE, progress = "text",
                filename = here("derived", "0420_06-7-pred_sd_2018_100runs.tif"),overwrite=TRUE)
# is sd and mean value strongly correlated? yea, a bit
pred_mean <- calc(st1, mean, na.rm = TRUE, progress = "text")

st2 <- stack(pred_mean, pred_sd)
st_df <- as.data.frame(st2, xy = TRUE, na.rm = TRUE)
#将第三列重命名为 val，将第四列重命名为 sd
st_df <- st_df %>% rename(val = 3, sd = 4)
## Finish plot SD ----------------------------------------------------------

# better: SD divided by mean
st_df <- st_df %>% mutate(rel_sd= sd/val) %>%
  mutate(pid = glc_pIDfromXY(x, y)) 
predplot <- full_join(st_df %>% select(-c(x,y)), pred , by = "pid")
saveRDS(predplot,here("rds","06-2-uncertainty_data.rds"))
predplot <- readRDS("rds/06-2-uncertainty_data.rds")
map<-ggplot()+
  geom_tile(data = predplot, aes(x=x, y=y, fill=rel_sd))+
  borders(colour = NA, ylim = c(-60, 90))+
  
  #geom_raster(aes(fill = value))+
  scale_fill_gradient(high = "#DC3535",low = "#FFE15D", na.value = "grey90",
                      name = "Coefficient of variation") +
  coord_fixed()+
  theme_void()+
  theme(legend.position = c(0.14, 0.22),
        legend.title = element_text(face = "bold"),
        # legend.key = element_rect(size = 3, fill = "white", colour = NA), # didn't work
        legend.key.width = unit(0.8, "cm")
        # legend.key.height = unit(1, "cm")
  ) 

map
ggsave(paste0("output/figures/","Coef of variation.pdf"),map,device = "pdf", width = 20,
       height = 10.2,units = "cm",dpi = 1000)


# 2007-2018 change ---------------------------------------------------------
 

pred_files <- list.files(here("eachyear/"), pattern = ".rds", full.names = TRUE)
# load all predictions (~ 2min)

#preds <- map_dfr(pred_files[c(1:12)],readRDS, .id = "year")
preds <- map_dfr(pred_files[c(1,12)],readRDS, .id = "year")
preds$year <- as.numeric(preds$year) + 2006
#删除prediction列中的空值
preds <- preds %>% drop_na(prediction)
pred2 <- preds  %>% select(c(x,y,year,pid,prediction)) %>%  nest(data = c(year,prediction))
change <- function(df, min_val = 2){
  n <- nrow(df)  
  if (n < min_val){
    diff <- NA
    
  } else {
    df <- df %>% as.data.frame()
    diff<-diff(df[,-1])
  }
  c(diff=diff)
}
dat1 <- pred2$data[[1]] %>% as.data.frame()
nrow(dat1)
diff(dat1[,-1])
change(df = dat1)

pred2 <- pred2 %>% 
  mutate(list = imap(data, ~ {if (.y %% 50000 == 0) cat(.y, "done\n");
    change(.x)} )) 
pred_diff <- pred2 %>% 
  mutate(diff = map_dbl(list,1)) %>% 
  unnest() %>%
  filter(year =="2007") %>%
  mutate(percent = diff/prediction*100) %>% 
  select(-c(list))

breaks <- c(-Inf,-35,-20,-5,0,5,20,35,Inf)
df <- pred_diff %>% mutate(cut = cut(percent, breaks = breaks,
                                     include.lowest = TRUE)) %>%
  mutate(cut= as.factor(cut)) %>% as.data.frame() %>% select(-c(x,y))
preddf<-readRDS("derived/06-2-preddf.rds")
df <- full_join(df , preddf, by = "pid")
saveRDS(df,paste0("rds/preddf_change——cut.rds"))
df  <- readRDS("rds/preddf_change——cut.rds")
my_colormap <- brewer.pal(11, 'PuOr')[c(2:4,7:11)]
futurechange <- ggplot() +
  geom_tile(data = df%>% drop_na(percent), aes(x=x, y=y, fill=percent)) +
  borders(colour = 'black', fill = NA, ylim = c(-60, 90))+
  coord_fixed(xlim = c(-180, 180), expand = FALSE)+
  scale_fill_gradientn(colours = my_colormap,name="Percent of EMF change(%)",breaks = c(-Inf,-40, -20, -10, -5, 0, 5, 10, 20, 40,Inf)) +
  labs(
    #title = "Percent of EMF change for 2018-2060",
    x = "Longitude",
    y = "Latitude"
  ) +
  theme_void()+
  theme_bw() +
  theme(
    plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 15.5),
    legend.title = element_text(face="bold",size=16),
    legend.direction = "horizontal",
    legend.position = c(0.65,0.07),
    legend.key.width = unit(2.4, "cm"),
    legend.key.height = unit(0.7,"cm"),
    axis.text = element_text(size = 15),  # 调整横纵坐标刻度的字体大小
    axis.title = element_text(size = 15)) +
  guides(
    fill = guide_coloursteps(
      title.position = "top",
      title.hjust = 0.5,
      keywidth = unit(6, "cm"),
      keyheight = unit(12, "cm"),
      label.theme = element_text(size = 12)
    )
  )
map <- ggplot() +
  geom_tile(data = df, aes(x=x, y=y, fill=percent)) +
  borders(colour = NA, ylim = c(-60, 90))+
  coord_fixed(xlim = c(-180, 180), expand = FALSE)+
  scale_fill_gradientn(colours = my_colormap,na.value = "grey90",name="Percent of EMF change(%)",breaks = c(-Inf,-40, -20, -10, -5, 0, 5, 10, 20, 40,Inf)) +
  labs(
    title ="Percent of EMF change for 2007-2018")+
  theme_void()+
  theme(
    plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 13.5),
    legend.title = element_text(face="bold",size=9),
    legend.direction = "horizontal",
    legend.position = c(0.65,0.05),
    legend.key.width = unit(1.2, "cm"),
    legend.key.height = unit(0.4,"cm")) +
  guides(fill=guide_coloursteps(title.position="top"))
map

ggsave(paste0("output/figures/","0714-2007-2018change.pdf"),map,device = "pdf", width = 20,
       height = 10.2,units = "cm")
#对地图进行分区，按照difference大于15和小于15
#给df文件根据diff添加一列difference，当diff列的值大于15时，difference为1，否则为0
newdf <- df %>%
  mutate(LST_ = case_when(difference > 15 ~ "1",
                          difference < 15 ~ "0"))
difference <- raster("resample/dynamic/difference/difference_2018.tif")
reclass <- cbind(c(-Inf, 15, 0), c(15, Inf, 1))
r_reclass <- reclassify(difference, reclass)
r_poly <- rasterToPolygons(r_reclass, dissolve = TRUE)
r_poly$label <- ifelse(r_reclass[] > 15, ">15", "<=15")
r_poly <- st_read("1978-2000/poly.shp")
map <- ggplot() +
  
  geom_tile(data = df, aes(x=x, y=y, fill=percent)) +
  geom_sf(data = r_poly, fill = "transparent", color = "black") +
  borders(colour = NA, ylim = c(-60, 90))+
  coord_sf(xlim = c(-180, 180), ylim = c(-60, 90), crs = st_crs(4326))+
  scale_fill_gradientn(colours = my_colormap,na.value = "grey90",name="Percent of EMF change(%)",breaks = c(-Inf,-40, -20, -10, -5, 0, 5, 10, 20, 40,Inf)) +
  labs(
    title ="Percent of EMF change for 2018-2060")+
  theme_void()+
  theme(
    plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 13.5),
    legend.title = element_text(face="bold",size=9),
    legend.direction = "horizontal",
    legend.position = c(0.65,0.05),
    legend.key.width = unit(0.8, "cm"),
    legend.key.height = unit(0.4,"cm")) +
  guides(fill=guide_coloursteps(title.position="top"))
map 


# EMF change of 2007-2018 in different region -----------------------------

vars <- c("Land_cover","MAT","MAP","aridity","soil_temp","HFP","elev"
          ,"phh2o" ,"cec"
          ,"difference"
          ,"sand","clay"#,"abs_latitude"
          ,"plant_SR","plant_PR"
          ,"bacteria_SR","bacteria_PD")
ipras <- raster(here("geodata", "09-ipbes_subregions_alphaOrder.tif"))
names(ipras) <- "ipbco"

levs <- c("Antarctica", "Caribbean", "Central Africa", "Central and Western Europe", 
          "Central Asia", "East Africa and adjacent islands", "Eastern Europe", 
          "Mesoamerica", "North-East Asia", "North Africa", "North America", 
          "Oceania", "South-East Asia", "South America", "South Asia", 
          "Southern Africa", "West Africa", "Western Asia")
#不同区域对应编码
match_tbl <- tibble(ipbsr = levs,
                    code = 1:length(ipbsr))
ip_df <- as.data.frame(ipras, xy = TRUE, na.rm = TRUE)
ip_df <- ip_df %>% 
  left_join(match_tbl, by = c("ipbco" = "code")) %>% 
  mutate(pid = glc_pIDfromXY(x, y)) %>% 
  dplyr::select(-c(x,y))
get_raster_change_climate<-function(layer,year=NULL){
  slgrds <- c("aridity","cec","clay","phh2o","sand","elev","plant_SR","plant_PR"
              ,"bacteria_SR","bacteria_PD"
              ,"mammals","amphibians")
  dynamic <- c("MAT","MAP","soil_temp","HFP","difference","Land_cover")
  
  if (layer %in% slgrds){
    rpath <- here("resample/static/", paste0("resamp_",layer,".tif")) 
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "MAT"){
    rpath <- here("resample/dynamic/MAT/",paste0(layer,"_",year,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "MAP"){
    rpath <- here("resample/dynamic/MAP/",paste0(layer,"_",year,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "soil_temp"){
    rpath <- here("resample/dynamic/soil_temp/",paste0(layer,"_",2007,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "difference"){
    rpath <- here("resample/dynamic/difference/",paste0(layer,"_",2007,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "Land_cover"){
    rpath <- here("resample/dynamic/Land_cover/",paste0(layer,"_",2007,".tif"))
    ras <- raster::raster(rpath) 
    
  } else if (layer == "HFP"){
    rpath <- here("resample/dynamic/HFP/",paste0(layer,"_",2007,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else {
    stop("Not a valid layer")
  }
  ras
}
get_raster_change_lui<-function(layer,year=NULL){
  slgrds <- c("aridity","cec","clay","phh2o","sand","elev","plant_SR","plant_PR"
              ,"bacteria_SR","bacteria_PD"
              ,"mammals","amphibians")
  dynamic <- c("MAT","MAP","soil_temp","HFP","difference","Land_cover")
  
  if (layer %in% slgrds){
    rpath <- here("resample/static/", paste0("resamp_",layer,".tif")) 
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "MAT"){
    rpath <- here("resample/dynamic/MAT/",paste0(layer,"_",2007,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "MAP"){
    rpath <- here("resample/dynamic/MAP/",paste0(layer,"_",2007,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "soil_temp"){
    rpath <- here("resample/dynamic/soil_temp/",paste0(layer,"_",2007,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "difference"){
    rpath <- here("resample/dynamic/difference/",paste0(layer,"_",2007,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "Land_cover"){
    rpath <- here("resample/dynamic/Land_cover/",paste0(layer,"_",year,".tif"))
    ras <- raster::raster(rpath) 
    
  } else if (layer == "HFP"){
    rpath <- here("resample/dynamic/HFP/",paste0(layer,"_",2007,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else {
    stop("Not a valid layer")
  }
  ras
}
for (i in c(2018)){
  all <- stack(map(vars, ~get_raster_change_climate(.x, i)))
  names(all) <- vars
  grid <- as.data.frame(all, xy = TRUE, na.rm = TRUE)
  
  grid <- grid %>%
    mutate(aridity = aridity/10000) %>%
    mutate(sand = sand/10) %>%
    mutate(clay=clay/10) %>%
    mutate(phh2o=phh2o/10) %>%
    #mutate(bd=bd/100) %>%
    mutate(soil_temp=soil_temp-273.15) %>%
    mutate(abs_latitude = abs(y))
  # fix Land_cover col
  grid <- grid %>% 
    mutate(Land_cover = glc_LC_num2chr(Land_cover)) %>% 
    filter(Land_cover %in% c("F","C","G","D")) %>% 
    mutate(Land_cover = factor(Land_cover)) %>%
    mutate(pid = glc_pIDfromXY(x, y))
  preddf<-readRDS("derived//06-2-preddf.rds") %>% select(c("pid","Category"))
  pred <- full_join(grid, preddf, by = "pid") 
  preddata <- pred %>% 
    filter(Category == "Predicted") %>%
    select(-c("pid","Category")) %>%
    na.omit(preddata)
  head(preddata)
  #saveRDS(pred, here("rds", paste0("06-2-grid-",i,".rds")))
  all(names(preddata %>% select(-c(x, y))) %in% names(model$trainingData))
  
  # predict from stack.as.df (~1min)
  prediction <- predict(model, preddata %>% select(-c(x, y))) %>% unname
  predplot<-cbind(preddata[1:2],prediction)
  predplot <- predplot %>% mutate(pid = glc_pIDfromXY(x, y)) %>% select(-c(x,y))
  head(pred)
  head(predplot)
  #conflicts_prefer(parallel::stopCluster)
  full <- full_join(pred, predplot, by = "pid") 
  head(full)
  saveRDS(full, paste0("eachyear/0914_change_climators_two.rds"))
}
bardata <- list()
sumdata <- list()
for (i in c(4:...)){
  pred_files <- list.files(here("change//"), pattern = ".rds", full.names = TRUE)
  # load all predictions (~ 2min)
  
  preds <- map_dfr(pred_files[c(1,i)],readRDS, .id = "year")
  #preds <- map_dfr(pred_files,readRDS, .id = "year")
  
  preds$year <- as.numeric(preds$year) + 2006
  #删除prediction列中的空值
  preds <- preds %>% drop_na(prediction)
  pred2 <- preds  %>% select(c(year,pid,prediction)) %>%  nest(data = c(year,prediction))
  change <- function(df, min_val = 2){
    n <- nrow(df)  
    if (n < min_val){
      diff <- NA
      
    } else {
      df <- df %>% as.data.frame()
      diff<-diff(df[,-1])
    }
    c(diff=diff)
  }
  dat1 <- pred2$data[[1]] %>% as.data.frame()
  nrow(dat1)
  diff(dat1[,-1])
  change(df = dat1)
  
  pred2 <- pred2 %>% 
    mutate(list = imap(data, ~ {if (.y %% 50000 == 0) cat(.y, "done\n");
      change(.x)} )) 
  pred_diff <- pred2 %>% 
    mutate(diff = map_dbl(list,1)) %>% 
    filter(!list == "c(diff = 0)") %>%
    unnest() %>%
    filter(year =="2007") %>%
    mutate(percent = diff/prediction*100) %>% 
    select(-c(list))
  preddf<-readRDS("derived/06-2-preddf.rds")
  df <- full_join(pred_diff, preddf, by = "pid")
  saveRDS(df, here(paste0("rds/0914change//df_all_change_",i,"_",".rds")))
  df <- df %>% drop_na(percent)
  sumdata[[i]] <- full_join(df %>% drop_na(percent), ip_df , by = "pid")
  bardata[[i]] <- sumdata[[i]] %>% filter(Category == "Predicted")
  
  my_colormap <- brewer.pal(11, 'PuOr')[c(2:4,7:11)]
  map <- ggplot() +
    geom_tile(data = df, aes(x=x, y=y, fill=percent)) +
    borders(colour = "black", ylim = c(-60, 90))+
    coord_fixed(xlim = c(-180, 180), expand = FALSE)+
    scale_fill_gradientn(colors = my_colormap,na.value = "white",name="Percent of EMF change(%)") +
    labs(
      #title = "Percent of EMF change for 2018-2060",
      x = "Longitude",
      y = "Latitude"
    ) +
    theme_bw()+
    theme(
      plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 30),
      legend.title = element_text(face="bold",size=15),
      legend.direction = "horizontal",
      #panel.grid.major = element_blank(),  # 移除主要网格线
      # panel.grid.minor = element_blank(),  # 移除次要网格线
      legend.position = c(0.13,0.11),
      legend.key.width = unit(1.4, "cm"),
      legend.key.height = unit(0.7,"cm"),
      panel.grid.major=element_line(colour=NA),
      panel.background = element_rect(fill = "transparent",colour = NA),
      plot.background = element_rect(fill = "transparent",colour = NA),
      panel.grid.minor = element_blank(),
      # axis.title.x = element_text(size = 15),
      # axis.title.y =element_text(size = 15),
      #axis.text.x=element_text(size = 15),
      axis.ticks.x=element_line(linewidth = 0.8),
      #axis.text.y=element_text(size = 15),
      axis.ticks.y=element_line(linewidth = 0.8),
      axis.text = element_text(size = 20),  # 调整横纵坐标刻度的字体大小
      axis.title = element_text(size = 20))+
    guides(fill = guide_coloursteps(
      title.position = "top",
      title.hjust = 0.5,
      # keywidth = unit(0.1, "cm"),
      # keyheight = unit(0.4, "cm"),
      label.theme = element_text(size = 13)
    ))
  
  map
  ggsave(paste0("output/figures/eachyear_","0903_climate_two_change_",i,"_",".png"),map,device = "png", width = 40,
         height = 21,units = "cm",dpi=300)
}
saveRDS(bardata,here(paste0("rds/bardata_0914.rds")))
bardata <- readRDS("rds/bardata.rds")
# 创建一个空的数据框用于存储提取的数据
data_extract <- data.frame()

# 循环提取数据并组合到新数据框中,2018年的
for (i in c(2, 4, 5)) {
  if (i ==5) {
    group_name <- "only land cover"
  } else if (i == 4) {
    group_name <- "only climate"
  } else if (i == 2) {
    group_name <- "all"
  } 
  
  data <- bardata[[i]]
  extracted_data <- data[, c("ipbsr", "percent")]
  extracted_data$Group <- group_name
  data_extract <- rbind(data_extract, extracted_data)
}
positive_count <- sum(data_extract$percent > 0)
negative_count <- sum(data_extract$percent  < 0)

# 计算正负值的比例
positive_ratio <- positive_count / nrow(data_extract)
negative_ratio <- negative_count / nrow(data_extract)

# 打印结果
cat("正值比例:", positive_ratio, "\n")
cat("负值比例:", negative_ratio, "\n")

p <- ggplot(data_extract %>% drop_na(ipbsr), aes(x = percent, y =ipbsr , fill = Group)) +
  geom_boxplot(outlier.shape = NA) +
  scale_fill_manual(values = c("#cab2d6",
                               "#b2df8a",
                               "#FFD95A"))+
  xlim(-20,20)+
  labs(x="",y="")+
  theme_bw()+
  theme(plot.title = element_markdown(hjust = 0.85,vjust = 0.8,color = "black",size = 50),
        legend.title = element_blank(),
        legend.position = "none",
        panel.border = element_blank(), 
        panel.grid.major = element_blank(),  # 移除主要网格线
        panel.grid.minor = element_blank(),  # 移除次要网格线
        legend.direction = "horizontal",
        legend.key.width = unit(10, "cm"),
        legend.key.height = unit(2.5,"cm"),
        axis.ticks.x = element_blank(),axis.text.x = element_blank(),
        axis.ticks.y = element_blank(),axis.text.y = element_blank())
p
ggsave("output/bar_all_climators.pdf",p,device = "pdf",width = 8.7,height=10)
leg <- get_legend(p)
ggsave("output/leg_change_now_all_climators.pdf",leg,device="pdf",width = 20,height = 4)

#######################################################################################
#######################################################################################
############以2018年为基线调整不同土地利用类型比例计算EMF变化量#################### ################


for (ii in  c("Central and Western Europe", 
              "Central Asia","Eastern Europe",  "North-East Asia", "North America", 
              "Oceania", "South-East Asia", "South America", "South Asia", 
              "Southern Africa",.....)){
  glc_predicted_dataset <- function() {
    readRDS(here("eachyear/0524_full_2018.rds"))}
  preds <- glc_predicted_dataset()
  preddf<-readRDS("derived//06-2-preddf.rds") %>% select(c("pid"))
  pred <- full_join(preds, preddf,by = "pid")
  #导入分区文件
  ip_df <- as.data.frame(ipras, xy = TRUE, na.rm = TRUE)
  ip_df <- ip_df %>% 
    left_join(match_tbl, by = c("ipbco" = "code")) %>% 
    mutate(pid = glc_pIDfromXY(x, y)) %>% 
    dplyr::select(-c(x,y))
  pred <- full_join(pred,ip_df,by = "pid")
  preddata <- pred %>% 
    filter(Category == "Predicted") %>%
    select(-c("Category","ipbco")) %>%
    filter(ipbsr == ii) %>% 
    na.omit(preddata)
  prop <- prop.table(table(preddata$Land_cover))
  prop["F"] %>% as.numeric()
  head(preddata)
  #saveRDS(pred, here("rds", paste0("06-2-grid-",i,".rds")))
  all(names(preddata %>% select(-c(x, y,"ipbsr","pid","prediction"))) %in% names(model$trainingData))
  for (i in c(0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9)){
    num_to_change <- round(sum(preddata$Land_cover == "F") * i)
    indices_of_CF <- which(preddata$Land_cover == "F")
    indices_to_change <- sample(indices_of_CF, size = num_to_change, replace = FALSE)
    preddata$Land_cover[indices_to_change] <- "C"
    prop <- prop.table(table(preddata$Land_cover))
    F_prop <- prop["F"] %>% as.numeric() %>% round(.,3)
    # predict from stack.as.df (~1min)
    prediction <- predict(model, preddata %>% select(-c(x, y,"ipbsr","pid","prediction"))) %>% unname
    pred<-cbind(preddata,prediction)
    #pred <- pred %>% as.data.frame() %>% mutate(pid = glc_pIDfromXY(x, y)) 
    head(pred)
    #head(preddf)
    #full <- full_join(pred, preddf, by = "pid")
    #head(full)
    saveRDS(pred, here(paste0("eachyear/LUI_change_f_c_",ii,"_",i,".rds")))
  }
}
# 计算变化量 -------------------------------------------------------------------
for (i in c(13:21)){
  pred_files <- list.files(here("eachyear/"), pattern = ".rds", full.names = TRUE)
  # load all predictions (~ 2min)
  
  preds <- map_dfr(pred_files[c(12,i)],readRDS, .id = "year")
  #preds <- map_dfr(pred_files,readRDS, .id = "year")
  
  preds$year <- as.numeric(preds$year) + 2017
  #删除prediction列中的空值
  preds <- preds %>% drop_na(prediction)
  pred2 <- preds  %>% select(c(year,pid,prediction)) %>%  nest(data = c(year,prediction))
  change <- function(df, min_val = 2){
    n <- nrow(df)  
    if (n < min_val){
      diff <- NA
      
    } else {
      df <- df %>% as.data.frame()
      diff<-diff(df[,-1])
    }
    c(diff=diff)
  }
  dat1 <- pred2$data[[1]] %>% as.data.frame()
  nrow(dat1)
  diff(dat1[,-1])
  change(df = dat1)
  
  pred2 <- pred2 %>% 
    mutate(list = imap(data, ~ {if (.y %% 50000 == 0) cat(.y, "done\n");
      change(.x)} )) 
  pred_diff <- pred2 %>% 
    mutate(diff = map_dbl(list,1)) %>% 
    filter(!list == "c(diff = 0)") %>%
    unnest() %>%
    filter(year =="2019") %>%
    mutate(percent = diff/prediction*100) %>% 
    select(-c(list))
  preddf<-readRDS("derived/06-2-preddf.rds")
  df <- full_join(preddf, pred_diff, by = "pid")
  saveRDS(df,here(paste0("eachyear/0903_LUI_change_f_C_percent",F_prop,".rds")))
}

sumdata <- list()
for (i in c(2:9)){
  seri <- serino[i]
  pred_files<- list.files(here("eachyear/..."), pattern = ".rds", full.names =TRUE)
  preds <- map_dfr(pred_files[c(1,i)],readRDS, .id = "year")
  #preds <- map_dfr(pred_files,readRDS, .id = "year")
  preds$year <- as.numeric(preds$year) + 2017
  #删除prediction列中的空值
  preds <- preds %>% drop_na(prediction)
  pred2 <- preds  %>% dplyr::select(c(x,y,year,pid,prediction)) %>%  nest(data = c(year,prediction))
  change <- function(df, min_val = 2){
    n <- nrow(df)  
    if (n < min_val){
      diff <- NA
    } else {
      df <- df %>% as.data.frame()
      diff<-diff(df[,-1])
    }
    c(diff=diff)
  }
  dat1 <- pred2$data[[1]] %>% as.data.frame()
  nrow(dat1)
  diff(dat1[,-1])
  change(df = dat1)
  pred2 <- pred2 %>% 
    mutate(list = imap(data, ~ {if (.y %% 50000 == 0) cat(.y, "done\n");
      change(.x)} )) 
  #保留2018年的数据作为分母，计算变化百分数
  pred_diff <- pred2 %>% 
    mutate(diff = map_dbl(list,1)) %>% 
    unnest(cols = c(data, list)) %>%
    filter(year =="2018") %>%
    mutate(percent = diff/prediction*100) %>% 
    dplyr::select(-c(list))
  preddf<-readRDS("derived/06-2-preddf.rds")
  sumdata[[i]] <- full_join(pred_diff%>% dplyr::select(-c(x,y)), preddf , by = "pid")
  bardata[[i]] <- sumdata[[i]] %>% filter(Category == "Predicted")
  
  bardata[[i]] <- bardata[[i]]  %>% mutate(LST_diff= if_else(bardata[[i]]$difference > 15, 'LST_diff > 15', 'LST_diff <= 15'))
  bardata[[i]] <- bardata[[i]] %>% drop_na(percent)
}
saveRDS(sumdata,here(paste0("rds/sumdata_lui.rds")))


bardata <- readRDS("rds/sumdata_lui.rds")
# 创建一个空的数据框用于存储提取的数据
data_extract <- data.frame()

# 循环提取数据并组合到新数据框中
for (i in c(1:9)) {
  if (i ==1) {
    group_name <- "90%"
  } else if (i == 8) {
    group_name <- "80%"
  } .......else if (i == 2) {
    group_name <- "20%"
  } else if (i == 1) {
    group_name <- "10%"
  }
  
  data <- bardata[[i]]
  extracted_data <- data[, c("ipbsr", "percent","pid","x","y")]
  extracted_data$Group <- group_name
  data_extract <- rbind(data_extract, extracted_data)
}

p <- ggplot(data_extract, aes(x = percent, y = Group, fill = ipbsr)) +
  geom_boxplot(outlier.shape = NA) +
  scale_fill_manual(values = c("#"...))+
  xlim(-15,15)+
  labs(x="",y="")+
  theme_bw()+
  theme(plot.title = element_markdown(hjust = 0.05,vjust = 1,color = "black",size = 50),
        legend.title = element_blank(),
        legend.direction = "horizontal",
        legend.key.width = unit(10, "cm"),
        legend.key.height = unit(2.5,"cm"),
        axis.ticks.y = element_blank(),axis.text.y = element_blank())

ggsave("output/...to...change-bar.pdf",device = "pdf",width = 5.7,height=10)