# -*- coding: utf-8 -*-
"""
Created on Sat Aug 20 12:03:29 2022

@author: 影子
"""
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import mean_absolute_error,mean_squared_error,explained_variance_score,r2_score
from sklearn.model_selection import train_test_split
import numpy as np
import pandas as pd
from sklearn.model_selection import GridSearchCV
from sklearn.model_selection import ShuffleSplit
from sklearn.inspection import permutation_importance
from sklearn.model_selection import cross_validate, KFold
from matplotlib import pyplot as plt
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_percentage_error as MAPE
from sklearn.metrics import mean_squared_error, mean_absolute_error, explained_variance_score
from tqdm import tqdm,trange
import random
from sklearn.preprocessing import StandardScaler
def rmse(obs,pre):
    return np.sqrt(mean_squared_error(obs, pre))
def R2(obs,pre):
    return r2_score(obs, pre)    
def caculate_cor():
    global r_test,r_train,y_test_pred,y_train_pred,rmse_test,rmse_train,train_R2,test_R2,train_mape,test_mape
    y_test_pred=pd.DataFrame(svr.predict(x_test).reshape(y_test.shape),index=test_index)
    r_test=np.corrcoef(y_test_pred[0],y_test[colnames[0]])
    y_train_pred=pd.DataFrame(svr.predict(x_train).reshape(y_train.shape),index=train_index)
    r_train=np.corrcoef(y_train_pred[0],y_train[colnames[0]])
    rmse_test=rmse(y_test[colnames[0]],y_test_pred[0])
    rmse_train=rmse(y_train[colnames[0]],y_train_pred[0])
    train_R2=R2(y_train,y_train_pred)
    test_R2= R2(y_test,y_test_pred)  
    train_mape=MAPE(y_train, y_train_pred)
    test_mape=MAPE(y_test, y_test_pred)
#加载数据集

xl = pd.ExcelFile('RF20221009_821.xlsx')
namelist=xl.sheet_names[0:3]
print(namelist)
#predf=pd.read_excel('experiment materials.xlsx',sheet_name=1).iloc[0:5,0:31]

writer1=pd.ExcelWriter('821-svm-op-gsearch-poly.xlsx')
writer2=pd.ExcelWriter('821-svm-cor-gsearch-poly.xlsx')
#writer4=pd.ExcelWriter('821-val.xlsx')
#writer5=pd.ExcelWriter('821-pre.xlsx')
#writer6=pd.ExcelWriter('ss-index-all.xlsx')
for i in trange(0,3):
    data=pd.read_excel('RF20221009_821.xlsx',sheet_name=i)
    data.dropna(axis=0,inplace=True)
    if i<2:
        random.seed(1)
    else:
        random.seed(2)
    val=random.sample(range(0,len(data)),5)
    model_index=list(data.index)
    for j in val:
        model_index.remove(j)
    #x_data=data[globals()['colindex'+str(i)]]
    valdata=data.iloc[val,:]
    val_x=valdata.iloc[:,1:-1]
    val_y=valdata.iloc[:,-1:]
    #iloc[:,-1]时截出的y是一个series，iloc[:,-1:]是dataframe
    data=data.loc[model_index,:]
    x_data=data.iloc[:,1:-1]
    y_data=data.iloc[:,-1:]
    y_data.index=range(len(y_data))
    x_names=x_data.columns.values.tolist()
    colnames=y_data.columns.values.tolist()
    
    ss=ShuffleSplit(n_splits=10, test_size=0.1,random_state=0)
    #stdsc=StandardScaler()
    prelist=[]
    vallist=[]
    corlist_train=[]
    corlist_test=[]
    rmsel_train=[]
    rmsel_test=[]
    r2_train=[]
    r2_test=[]
    o=[]

    
    with tqdm(total=10) as pbar:
        for train_index , test_index in ss.split(x_data,y_data):
            x_train=x_data.iloc[train_index,:]
            x_train.columns=x_names
            y_train=y_data.iloc[train_index,:].values.ravel()            
            x_test=x_data.iloc[test_index,:]
            x_test.columns=x_names        
            y_test=y_data.iloc[test_index,:].values.ravel() 
            #创建svR实例
            svr=SVR(C=1, kernel='rbf', epsilon=0.2)
            svr=svr.fit(x_train,y_train)

            # 设置超参数
            C = [0.1, 0.2, 0.5, 0.8, 0.9, 1, 2, 5, 10]
            kernel = 'rbf'
            gamma = [0.001, 0.01, 0.1, 0.2, 0.5, 0.8]
            epsilon = [0.01, 0.05, 0.1, 0.2, 0.5, 0.8]
            # 参数字典
            params_dict = {
                'C': C,
                'gamma': gamma,
                'epsilon': epsilon
            }

            # 创建SVR实例
            svr = SVR()

            # 网格参数搜索
            gsCV = GridSearchCV(
                estimator=svr,
                param_grid=params_dict,
                scoring='r2',
                cv=6
            )
            gsCV.fit(x_train, y_train)
            # 输出参数信息
            print("最佳度量值:", gsCV.best_score_)
            print("最佳参数:", gsCV.best_params_)
            print("最佳模型:", gsCV.best_estimator_)
            #最佳度量值: 0.3856746247583727
            #最佳参数: {'C': 0.2, 'epsilon': 0.01, 'gamma': 0.001}
            #最佳模型: SVR(C=0.2, epsilon=0.01, gamma=0.001)

            # 用最佳参数生成模型
            svr = SVR(C=gsCV.best_params_['C'], kernel=kernel, gamma=gsCV.best_params_['gamma'],
                      epsilon=gsCV.best_params_['epsilon'])
            for k in [x_train, x_test]:
               k.index = range(k.shape[0])
            svr.fit(x_train,y_train)
            '''
            val_one=model.predict(val_x)
            vallist.append(val_one.T)
            pre_one=model.predict(predf)
            prelist.append(pre_one.T)
            '''
            caculate_cor()
            corlist_train.append(r_train[1,0])
            corlist_test.append(r_test[1,0])
            rmsel_train.append(rmse_train)
            rmsel_test.append(rmse_test)
            r2_train.append(train_R2)
            r2_test.append(test_R2)
            #scatter_loss_plot()
            o.append(y_train[colnames[0]])
            o.append(y_train_pred[0])
            o.append(y_test[colnames[0]])
            o.append(y_test_pred[0])
            pbar.update()           

    plt.show()        
    cordf=pd.DataFrame({'r2_train':r2_train,'r2_test':r2_test,
                        'train':corlist_train,'test':corlist_test,
                        'rmse_train':rmsel_train,'rmse_test':rmsel_test})
    obs_pre_df=pd.DataFrame([y_data[colnames[0]],o[1],o[5],o[9],o[13],o[17],o[21],o[25],o[29],o[33],o[37],
                            o[3],o[7],o[11],o[15],o[19],o[23],o[27],o[31],o[35],o[39]]).T
    obs_pre_df.columns=(colnames[0],'train1','train2','train3','train4','train5',
                        'train6','train7','train8','train9','train10',
                        'test1','test2','test3','test4','test5',
                        'test6','test7','test8','test9','test10')
    '''
    presult=pd.DataFrame(prelist,columns=['T','C','S','M','L']).T
    vresult=pd.DataFrame(vallist,columns=val).T
    vresult['observe']=val_y
    '''
    obs_pre_df.to_excel(writer1,sheet_name=colnames[0])
    cordf.to_excel(writer2,sheet_name=colnames[0])
    #presult.to_excel(writer4,sheet_name=colnames[0])
    #vresult.to_excel(writer5,sheet_name=colnames[0])
       
writer1.save()
writer2.save()
#writer3.save()
#writer4.save()
#writer5.save()


