# -*- coding: utf-8 -*-
"""
Created on Mon Jun 26 20:21:23 2023

@author: Administrator
"""

'''MLP'''
from keras import Sequential
from keras.layers.core import Dense,Activation,Dropout
from keras import optimizers
from tensorflow.keras.optimizers import SGD
from sklearn.neural_network import MLPRegressor
data=pd.read_excel("Desktop/2022/prediction/pred_bacteria/20230626diversity.xlsx")
data_encoded = pd.get_dummies(data['land_cover'])
data=pd.concat([data,data_encoded],axis=1)
#将某列移动到最后一列
col_to_move = 'faith_pd'
data.info()
data = data.assign(**{col_to_move: data.pop(col_to_move)})
data.drop(['sample-id','land_cover','Sand',"plant_PR"],axis=1, inplace = True)
data = data.dropna()
#model=MLPRegressor(activation='tanh'
                  # , learning_rate=0.0001
 #                  ,alpha=0.0001, hidden_layer_sizes=(1000,500,500))
#83-MLP-是alpha为0.1时建模

writer1=pd.ExcelWriter('C:/Users/Administrator/Desktop/2022/prediction/pred_bacteria/MLP-op.xlsx')
writer2=pd.ExcelWriter('C:/Users/Administrator/Desktop/2022/prediction/pred_bacteria/MLP-cor.xlsx')
#writer4=pd.ExcelWriter('821-val.xlsx')
#writer5=pd.ExcelWriter('821-pre.xlsx')
#writer6=pd.ExcelWriter('ss-index-all.xlsx')
for i in trange(2,3):
    #data=pd.read_excel('C:/Users/Administrator/Desktop/2023/models/MLP/RF20221009_821.xlsx',sheet_name=i)
    random.seed(2)
    model_index=list(data.index)
    val=random.sample(range(0,len(data)),5)
 
    for j in val:
        model_index.remove(j)
    #x_data=data[globals()['colindex'+str(i)]]
    valdata=data.iloc[val,:]
    val_x=valdata.iloc[:,0:-1]
    val_y=valdata.iloc[:,-1:]
    data=data.loc[model_index,:]
    x_data=data.iloc[:,0:-1]
    y_data=data.iloc[:,-1:]
    y_data.index=range(len(y_data))
    x_names=x_data.columns.values.tolist()
    colnames=y_data.columns.values.tolist()
    
    ss=ShuffleSplit(n_splits=10, test_size=0.1,random_state=0)
    #stdsc=StandardScaler()
    prelist=[]
    vallist=[]
    corlist_train=[]
    corlist_test=[]
    rmsel_train=[]
    rmsel_test=[]
    r2_train=[]
    r2_test=[]
    o=[]
    model=MLPRegressor(activation='tanh'
                       , learning_rate='adaptive'
                       ,alpha=1, hidden_layer_sizes=(1000,500))
    #model=MLPRegressor(activation='tanh'
     #                  , learning_rate='constant'
    #                   ,alpha=0.1
    #                   , hidden_layer_sizes=(1000,500,500))
    with tqdm(total=10) as pbar:
        for train_index , test_index in ss.split(x_data,y_data):
            x_train=x_data.iloc[train_index,:]
            x_train.columns=x_names
            y_train=y_data.iloc[train_index,:]            
            x_test=x_data.iloc[test_index,:]
            x_test.columns=x_names        
            y_test=y_data.iloc[test_index,:] 
            for k in [x_train, x_test]:
               k.index = range(k.shape[0])
            model.fit(x_train,y_train)
            '''
            val_one=model.predict(val_x)
            vallist.append(val_one.T)
            pre_one=model.predict(predf)
            prelist.append(pre_one.T)
            '''
            caculate_cor()
            corlist_train.append(r_train[1,0])
            corlist_test.append(r_test[1,0])
            rmsel_train.append(rmse_train)
            rmsel_test.append(rmse_test)
            r2_train.append(train_R2)
            r2_test.append(test_R2)
            #scatter_loss_plot()
            o.append(y_train[colnames[0]])
            o.append(y_train_pred[0])
            o.append(y_test[colnames[0]])
            o.append(y_test_pred[0])
            pbar.update()           

    plt.show()        
    cordf=pd.DataFrame({'r2_train':r2_train,'r2_test':r2_test,
                        'train':corlist_train,'test':corlist_test,
                        'rmse_train':rmsel_train,'rmse_test':rmsel_test})
    obs_pre_df=pd.DataFrame([y_data[colnames[0]],o[1],o[5],o[9],o[13],o[17],o[21],o[25],o[29],o[33],o[37],
                            o[3],o[7],o[11],o[15],o[19],o[23],o[27],o[31],o[35],o[39]]).T
    obs_pre_df.columns=(colnames[0],'train1','train2','train3','train4','train5',
                        'train6','train7','train8','train9','train10',
                        'test1','test2','test3','test4','test5',
                        'test6','test7','test8','test9','test10')
    '''
    presult=pd.DataFrame(prelist,columns=['T','C','S','M','L']).T
    vresult=pd.DataFrame(vallist,columns=val).T
    vresult['observe']=val_y
    '''
    obs_pre_df.to_excel(writer1,sheet_name=colnames[0])
    cordf.to_excel(writer2,sheet_name=colnames[0])
    #presult.to_excel(writer4,sheet_name=colnames[0])
    #vresult.to_excel(writer5,sheet_name=colnames[0])
       
writer1.save()
writer2.save()
#writer3.save()
#writer4.save()
#writer5.save()
