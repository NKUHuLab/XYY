# -*- coding: utf-8 -*-
"""
Created on Sat Oct  8 11:03:35 2022

@author: 影子
"""
import time
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.model_selection import ShuffleSplit
from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.inspection import permutation_importance
from sklearn.model_selection import cross_validate, KFold
from matplotlib import pyplot as plt
from sklearn.metrics import r2_score
from sklearn.metrics import mean_absolute_percentage_error as MAPE
from sklearn.metrics import mean_squared_error, mean_absolute_error, explained_variance_score
from tqdm import tqdm,trange
import random
from sklearn.preprocessing import StandardScaler
import shap
def rmse(obs,pre):
    return np.sqrt(mean_squared_error(obs, pre))
def R2(obs,pre):
    return r2_score(obs, pre)    
def caculate_cor():
    global r_test,r_train,y_test_pred,y_train_pred,rmse_test,rmse_train,train_R2,test_R2,train_mape,test_mape
    y_test_pred=pd.DataFrame(model.predict(x_test).reshape(y_test.shape),index=test_index)
    r_test=np.corrcoef(y_test_pred[0],y_test[colnames[0]])
    y_train_pred=pd.DataFrame(model.predict(x_train).reshape(y_train.shape),index=train_index)
    r_train=np.corrcoef(y_train_pred[0],y_train[colnames[0]])
    rmse_test=rmse(y_test[colnames[0]],y_test_pred[0])
    rmse_train=rmse(y_train[colnames[0]],y_train_pred[0])
    train_R2=R2(y_train,y_train_pred)
    test_R2= R2(y_test,y_test_pred)  
    train_mape=MAPE(y_train, y_train_pred)
    test_mape=MAPE(y_test, y_test_pred)

def scatter_loss_plot():
    plt.subplot(1,2,1)
    plt.ylim(-1,1)
    plt.xlim(-1,1)
    plt.plot(y_test[colnames[0]],y_test_pred[0],'.')

    
    plt.subplot(1,2,2)
    plt.ylim(-1,1)
    plt.xlim(-1,1)
    plt.plot(y_train[colnames[0]],y_train_pred[0],'.')


data=pd.read_csv("Desktop/2023/models/training.csv")
data_encoded = pd.get_dummies(data['Land_cover'])
data=pd.concat([data,data_encoded],axis=1)
#将某列移动到最后一列
col_to_move = 'EMF_mm'
data.info()
data = data.assign(**{col_to_move: data.pop(col_to_move)})
data.drop(['Land_cover','soil_age','bd','LSTd','LSTn','mammals','amphibians','soil biodiversity'],axis=1, inplace = True)
#namelist=data.sheet_names[0:13]
writer8= pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/RF/trainingdata.xlsx')
data.to_excel('C:/Users/Administrator/Desktop/2023/models/RF/trainingdata.xlsx', index=False)
#data.dropna(axis=0,inplace=True)
#model=RandomForestRegressor(n_estimators=500,oob_score=True,random_state=0,
#                                max_features='sqrt',min_samples_leaf=2)
                                #,max_depth=10)
#predf=pd.read_excel('experiment materials.xlsx',sheet_name=1).iloc[0:5,0:31]
writer1=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/RF/0527-rf-op.xlsx')
writer2=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/RF/0527-rrf-cor.xlsx')
writer3=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/RF/0527-rrf-imp.xlsx')
writer4=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/RF/0527-rval.xlsx')
writer5=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/RF/0527-rpre.xlsx')
#writer5=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/RF/0527-premutation.xlsx')
#writer6=pd.ExcelWriter('C:/Users/Administrator/Desktop/2022/new/dropna_dataset.xlsx')
for i in trange(0,1):
    #data=pd.read_excel('Desktop/2022/new/RF20221202_Python.xlsx',sheet_name=i)
    data.dropna(axis=0,inplace=True)
    
    random.seed(1)
    #if i<2:
    #    random.seed(1)
    #else:
    model_index=list(data.index)
    #    random.seed(2)
    val=random.sample(range(0,len(data)),5)
    
    for j in val:
        model_index.remove(j)
    #x_data=data[globals()['colindex'+str(i)]]
    valdata=data.iloc[val,:]
    val_x=valdata.iloc[:,3:22]
    val_y=valdata.iloc[:,-1:]
    #iloc[:,-1]时截出的y是一个series，iloc[:,-1:]是dataframe
    data=data.loc[model_index,:]
    x_data=data.iloc[:,3:22]
    y_data=data.iloc[:,-1:]
    y_data.index=range(len(y_data))
    x_names=x_data.columns.values.tolist()
    colnames=y_data.columns.values.tolist()
    
    ss=ShuffleSplit(n_splits=10, test_size=0.1,random_state=0)
    stdsc=StandardScaler()
    prelist=[]
    vallist=[]
    r2_train=[]
    r2_test=[]
    corlist_train=[]
    train_MAPE=[]
    test_MAPE=[]
    corlist_test=[]
    rmsel_train=[]
    rmsel_test=[]
    o=[]
    imp=[]
    model=RandomForestRegressor(n_estimators=500,oob_score=True,random_state=42
                                   ,max_features='sqrt'
                                    ,max_depth=7
                                    #,min_samples_leaf=3
                                    )
    
    #with tqdm(total=10) as pbar:
    for train_index , test_index in ss.split(x_data,y_data):
        x_train=x_data.iloc[train_index,:]
        #x_train=pd.DataFrame(stdsc.fit_transform(x_train),columns=x_names)
        x_train.columns=x_names
        
        y_train=y_data.iloc[train_index,:]
        #y_train=pd.DataFrame(stdsc.fit_transform(y_train).ravel(),columns=colnames)
        
        x_test=x_data.iloc[test_index,:]
        #x_test=pd.DataFrame(stdsc.fit_transform(x_test),columns=x_names)
        x_test.columns=x_names
        
        y_test=y_data.iloc[test_index,:]
       # y_test=pd.DataFrame(stdsc.fit_transform(y_test).ravel(),columns=colnames)
        model.fit(x_train,np.array(y_train).ravel())
        val_one=model.predict(val_x)
        vallist.append(val_one.T)
        #pre_one=model.predict(predf)
        #prelist.append(pre_one.T)
        caculate_cor()
        corlist_train.append(r_train[1,0])
        corlist_test.append(r_test[1,0])
        rmsel_train.append(rmse_train)
        rmsel_test.append(rmse_test)
        r2_train.append(train_R2)
        r2_test.append(test_R2)
        train_MAPE.append(train_mape)
        test_MAPE.append(test_mape)
        #scatter_loss_plot()
        o.append(y_train[colnames[0]])
        o.append(y_train_pred[0])
        o.append(y_test[colnames[0]])
        o.append(y_test_pred[0])
        #pbar.update()           
        imp.append(model.feature_importances_)
        # 计算 SHAP 值
        explainer = shap.Explainer(model)
        shap_values = explainer(x_train)
        shap.summary_plot(shap_values, x_train)
        # 绘制 SHAP 值重要性箱线图
        shap.summary_plot(shap_values, x_train, plot_type="bar", show=False)
        plt.title("SHAP Values Importance")
        plt.tight_layout()
        plt.savefig("C:/Users/Administrator/Desktop/2023/models/RF/shap_values.pdf", dpi=300)
    plt.show()        
    cordf=pd.DataFrame({'r2_train':r2_train,'r2_test':r2_test,
                    'train':corlist_train,'test':corlist_test,
                    'rmse_train':rmsel_train,'rmse_test':rmsel_test,
                    'train_mape':train_MAPE,'test_mape':test_MAPE})
    obs_pre_df=pd.DataFrame([y_data[colnames[0]],o[1],o[5],o[9],o[13],o[17],o[21],o[25],o[29],o[33],o[37],
                            o[3],o[7],o[11],o[15],o[19],o[23],o[27],o[31],o[35],o[39]]).T
    obs_pre_df.columns=(colnames[0],'train1','train2','train3','train4','train5',
                        'train6','train7','train8','train9','train10',
                        'test1','test2','test3','test4','test5',
                        'test6','test7','test8','test9','test10')
    presult=pd.DataFrame(prelist,columns=['T','C','S','M','L']).T
    vresult=pd.DataFrame(vallist,columns=val).T
    
    print(np.corrcoef(np.array(np.mean(vresult.T)).ravel(),
                          np.array(val_y).ravel())[0,1])
    vresult['predict']=np.array(np.mean(vresult.T)).ravel()
    vresult['observe']=val_y
    vresult['error']=vresult['predict']-vresult['observe']

    #imp_df=pd.DataFrame(imp,columns=globals()['colindex'+str(i)])
    imp_df=pd.DataFrame(imp,columns=x_names)
    obs_pre_df.to_excel(writer1,sheet_name=colnames[0])
    cordf.to_excel(writer2,sheet_name=colnames[0])
    imp_df.to_excel(writer3,sheet_name=colnames[0])
    presult.to_excel(writer4,sheet_name=colnames[0])
    vresult.to_excel(writer5,sheet_name=colnames[0])   
    
   # data.to_excel(writer6,sheet_name=colnames[0])
writer1.save()
writer2.save()
writer3.save()
writer4.save()
writer5.save()
model
g=pd.read_csv(r'D:/prediction/preddata.csv',index_col=())
g.info()
g_encoded = pd.get_dummies(g['Land_cover'])
g=pd.concat([g,g_encoded],axis=1)

scaler = StandardScaler()
g.drop(['Unnamed: 0','Land_cover','x','y'],axis=1, inplace = True)
g_scale = scaler.fit_transform(g.iloc[:,:-4])
columns=g.iloc[:,:-4].columns
g_ = pd.DataFrame(g_scale, columns=columns)

g = pd.concat([g_,g_encoded],axis=1)
model=RandomForestRegressor(n_estimators=500,oob_score=True,random_state=42
                                   ,max_features='sqrt'
                                    ,max_depth=7
                                    #,min_samples_leaf=3
                                    )
    

start =time.time()
explainer = shap.TreeExplainer(model)
shap_values = explainer(g)
end = time.time()
print('Running time: %s Seconds'%(end-start))
a=pd.DataFrame(shap_values.values)

a.columns = g.columns
a.to_csv(r'C:/Users/Administrator/Desktop/2023/models/shap_0704.csv')
#writer6.save()
"""
ss-index output
"""
writer6=pd.ExcelWriter('C:/Users/Administrator/Desktop/2022/new/ss-index-all.xlsx')
l_train_list=[]
l_test_list=[]
for i in trange(0,1):
    #frame=pd.read_excel('C:/Users/Administrator/Desktop/2022/new/dropna_dataset.xlsx',sheet_name=i)
    #frame.dropna(axis=0,inplace=True)
   # corresult=pd.read_excel('C:/Users/Administrator/Desktop/2022/new/821-rf-cor-mm.xlsx',sheet_name=i-1)
    #max_index=np.argmax(corresult['test'],axis=0)   
    frame = data
    random.seed(i)
    val=random.sample(range(0,len(frame)),5)
    model_index=list(frame.index)
    for j in val:
        model_index.remove(j)
    #x_data=frame[globals()['colindex'+str(i)]]
    frame=frame.loc[model_index,:]
    x_data=frame.iloc[:,1:-1]
    ss=ShuffleSplit(n_splits=10, test_size=0.1,random_state=0)
    index_list=[]
    for train_index in ss.split(x_data):
        index_list.append(train_index)
    index_train_list=index_list[max_index][0]
    index_df=pd.DataFrame(index_train_list)
    index_df.to_excel(writer6,sheet_name=namelist[i])

    l_train=len(index_list[0][0]) 
    l_test=len(index_list[0][1])
    l_train_list.append(l_train)
    l_test_list.append(l_test) 

writer6.save()

len_df=pd.DataFrame({'train':l_train_list,'test':l_test_list})
len_df.to_excel('C:/Users/Administrator/Desktop/2022/new/ss_len.xlsx')

''''
permutation test
'''
writer7=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/RF/0527-rpre.xlsx')
data = pd.read_excel('C:/Users/Administrator/Desktop/2023/models/RF/training.xlsx')
val = random.sample(range(0, len(data)), 5)
#namelist=data.sheet_names[0:1]
#data.dropna(axis=0,inplace=True)
model=RandomForestRegressor(n_estimators=500,oob_score=True,random_state=42
                                   ,max_features='sqrt'
                                    ,max_depth=7
                                    #,min_samples_leaf=3
                                    )
#writer7=pd.ExcelWriter('C:/Users/Administrator/Desktop/2022/new/permutation-all.xlsx')

for i in trange(0,1):
   # data=pd.read_excel('C:/Users/Administrator/Desktop/2022/new/dropna_dataset.xlsx',sheet_name=i)
    #data.dropna(axis=0,inplace=True)
    val=random.sample(range(0,len(data)),5)
    model_index=list(data.index)
    for j in val:
        model_index.remove(j)
    #x_data=data[globals()['colindex'+str(i)]]
    valdata=data.iloc[val,:]
    val_x=valdata.iloc[:,3:22]
    val_y=valdata.iloc[:,-1:]
    #iloc[:,-1]时截出的y是一个series，iloc[:,-1:]是dataframe
    data=data.loc[model_index,:]
    x_data=data.iloc[:,2:-1]
    y_data=data.iloc[:,-1:]
    y_data.index=range(len(y_data))
    x_names=x_data.columns.values.tolist()
    colnames=y_data.columns.values.tolist()
    
    ss=ShuffleSplit(n_splits=10, test_size=0.1,random_state=0)
    #stdsc=StandardScaler()
    r2_list=[]
    q2_list=[]
    model=RandomForestRegressor(n_estimators=500,oob_score=True,random_state=0,
                                    max_features='sqrt'
                                    ,max_depth=10
                                    #,min_samples_leaf=2
                                    )
    with tqdm(total=10) as pbar:
        for train_index , test_index in ss.split(x_data,y_data):
            x_train=x_data.iloc[train_index,:]
            x_train.columns=x_names
            y_train=y_data.iloc[train_index,:]
            x_test=x_data.iloc[test_index,:]
            x_test.columns=x_names        
            y_test=y_data.loc[test_index,:]
            print(len(x_train))
            for j in trange(5):
                for k in range(10):
                    random.seed(i+j+k)
                    #参数replace，用来设置是否可以取相同元素：True表示可以取相同数字；False表示不可以取相同数字。默认是True
                    per_index=np.random.choice(train_index,round((j+1)*0.2*len(x_train)),False)
                    y_train_per=y_train.copy()
                    for i_index in per_index:
                        y_train_per.loc[i_index,:]=np.random.uniform(-1,1)
                    model.fit(x_train,np.array(y_train_per).ravel())
                    r2_list.append(
                        np.corrcoef(y_train.iloc[:,0],y_train_per.iloc[:,0])[0,1])
                    y_array=np.array(y_test).ravel()
                    rss=np.sum((y_array-model.predict(x_test))**2)                          
                    tss=np.sum((y_array-np.mean(y_array))**2)
                    q2=1-rss/tss
                    q2_list.append(q2)
                
            model.fit(x_train,np.array(y_train))
            r2_list.append(1)
            rss=np.sum((y_array-model.predict(x_test))**2)                          
            tss=np.sum((y_array-np.mean(y_array))**2)
            q2=1-rss/tss
            q2_list.append(q2)
            pbar.update() 
             
    perdf=pd.DataFrame({'r2':r2_list,'q2':q2_list})
    
    plt.ylim(8,11)
    plt.xlim(8,11)
    plt.plot(perdf['r2'],perdf['q2'],'.')
    plt.show()
    perdf.to_excel(writer7,sheet_name=colnames[0])


writer7.save()
"""
SVM
最佳度量值: 0.12489844254026163
最佳参数: {'C': 0.5, 'epsilon': 0.01, 'gamma': 0.001}
最佳模型: SVR(C=0.5, epsilon=0.01, gamma=0.001)
"""
from sklearn.svm import SVR
from sklearn.preprocessing import StandardScaler
#predf=pd.read_excel('experiment materials.xlsx',sheet_name=1).iloc[0:5,0:31]
data=pd.read_csv("Desktop/2023/models/training.csv")
data_encoded = pd.get_dummies(data['Land_cover'])
data=pd.concat([data,data_encoded],axis=1)
#将某列移动到最后一列
col_to_move = 'EMF_mm'
data.info()
data = data.assign(**{col_to_move: data.pop(col_to_move)})
data.drop(['Land_cover','soil_age','bd','LSTd','LSTn','mammals','amphibians','soil biodiversity'],axis=1, inplace = True)

writer1=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/SVM/821-svm-op.xlsx')
writer2=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/SVM/821-svm-cor.xlsx')
#writer4=pd.ExcelWriter('821-val.xlsx')
#writer5=pd.ExcelWriter('821-pre.xlsx')
#writer6=pd.ExcelWriter('ss-index-all.xlsx')
for i in trange(1,2):
    
    random.seed(1)
    model_index=list(data.index)
    val=random.sample(range(0,len(data)),5)
    
    for j in val:
        model_index.remove(j)
    #x_data=data[globals()['colindex'+str(i)]]
    valdata=data.iloc[val,:]
    val_x=valdata.iloc[:,1:-1]
    val_y=valdata.iloc[:,-1:]
    #iloc[:,-1]时截出的y是一个series，iloc[:,-1:]是dataframe
    data=data.loc[model_index,:]
    x_data=data.iloc[:,1:-1]
    y_data=data.iloc[:,-1:]
    y_data.index=range(len(y_data))
    x_names=x_data.columns.values.tolist()
    colnames=y_data.columns.values.tolist()
    
    ss=ShuffleSplit(n_splits=10, test_size=0.1,random_state=0)
    #stdsc=StandardScaler()
    prelist=[]
    vallist=[]
    corlist_train=[]
    corlist_test=[]
    rmsel_train=[]
    rmsel_test=[]
    r2_train=[]
    r2_test=[]
    o=[]
    
    with tqdm(total=10) as pbar:
        for train_index , test_index in ss.split(x_data,y_data):
            x_train=x_data.iloc[train_index,:]
            x_train.columns=x_names
            y_train=y_data.iloc[train_index,:]            
            x_test=x_data.iloc[test_index,:]
            x_test.columns=x_names        
            y_test=y_data.iloc[test_index,:] 
            for k in [x_train, x_test]:
               k.index = range(k.shape[0])
            '''# 设置超参数
            C = [0.1, 0.2, 0.5, 0.8, 0.9, 1, 2, 5, 10]
            kernel = 'rbf'
            gamma = [0.001, 0.01, 0.1, 0.2, 0.5, 0.8]
            epsilon = [0.01, 0.05, 0.1, 0.2, 0.5, 0.8]
            # 参数字典
            params_dict = {
                'C': C,
                'gamma': gamma,
                'epsilon': epsilon
            }

            # 创建SVR实例
            model = SVR()

            # 网格参数搜索
            gsCV = GridSearchCV(
                estimator=model,
                param_grid=params_dict,
                scoring='r2',
                cv=6
            )
            gsCV.fit(x_train, y_train)
            # 输出参数信息
            print("最佳度量值:", gsCV.best_score_)
            print("最佳参数:", gsCV.best_params_)
            print("最佳模型:", gsCV.best_estimator_)
            #最佳度量值: 0.3856746247583727
            #最佳参数: {'C': 0.2, 'epsilon': 0.01, 'gamma': 0.001}
            #最佳模型: SVR(C=0.2, epsilon=0.01, gamma=0.001)

            # 用最佳参数生成模型
            model = SVR(C=gsCV.best_params_['C'], kernel=kernel, gamma=gsCV.best_params_['gamma'],
                      epsilon=gsCV.best_params_['epsilon'])
'''            
            for k in [x_train, x_test]:
               k.index = range(k.shape[0])
            model = SVR(C=1, kernel='rbf')   
            model.fit(x_train,y_train)
            '''
            val_one=model.predict(val_x)
            vallist.append(val_one.T)
            pre_one=model.predict(predf)
            prelist.append(pre_one.T)
            '''
            caculate_cor()
            corlist_train.append(r_train[1,0])
            corlist_test.append(r_test[1,0])
            rmsel_train.append(rmse_train)
            rmsel_test.append(rmse_test)
            r2_train.append(train_R2)
            r2_test.append(test_R2)
            scatter_loss_plot()
            o.append(y_train[colnames[0]])
            o.append(y_train_pred[0])
            o.append(y_test[colnames[0]])
            o.append(y_test_pred[0])
            pbar.update()           

    plt.show()        
    cordf=pd.DataFrame({'r2_train':r2_train,'r2_test':r2_test,
                        'train':corlist_train,'test':corlist_test,
                        'rmse_train':rmsel_train,'rmse_test':rmsel_test})
    obs_pre_df=pd.DataFrame([y_data[colnames[0]],o[1],o[5],o[9],o[13],o[17],o[21],o[25],o[29],o[33],o[37],
                            o[3],o[7],o[11],o[15],o[19],o[23],o[27],o[31],o[35],o[39]]).T
    obs_pre_df.columns=(colnames[0],'train1','train2','train3','train4','train5',
                        'train6','train7','train8','train9','train10',
                        'test1','test2','test3','test4','test5',
                        'test6','test7','test8','test9','test10')
    '''
    presult=pd.DataFrame(prelist,columns=['T','C','S','M','L']).T
    vresult=pd.DataFrame(vallist,columns=val).T
    vresult['observe']=val_y
    '''
    obs_pre_df.to_excel(writer1,sheet_name=colnames[0])
    cordf.to_excel(writer2,sheet_name=colnames[0])
    #presult.to_excel(writer4,sheet_name=colnames[0])
    #vresult.to_excel(writer5,sheet_name=colnames[0])
       
writer1.save()
writer2.save()
#writer3.save()
#writer4.save()
#writer5.save()

'xgb'
import xgboost as xgb
from xgboost import XGBRegressor
from sklearn.preprocessing import StandardScaler

data=pd.read_csv("Desktop/2023/models/training.csv")
data_encoded = pd.get_dummies(data['Land_cover'])
data=pd.concat([data,data_encoded],axis=1)
#将某列移动到最后一列
col_to_move = 'EMF_mm'
data.info()
data = data.assign(**{col_to_move: data.pop(col_to_move)})
data.drop(['Land_cover','soil_age','bd','LSTd','LSTn','mammals','amphibians','soil biodiversity'],axis=1, inplace = True)


writer1=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/XGB/xgb-op.xlsx')
writer2=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/XGB/xgb-cor.xlsx')
#writer4=pd.ExcelWriter('821-val.xlsx')
#writer5=pd.ExcelWriter('821-pre.xlsx')
#writer6=pd.ExcelWriter('ss-index-all.xlsx')
for i in trange(0,1):
    random.seed(1)
    model_index=list(data.index)
    val=random.sample(range(0,len(data)),5)
    
    for j in val:
        model_index.remove(j)
    #x_data=data[globals()['colindex'+str(i)]]
    valdata=data.iloc[val,:]
    val_x=valdata.iloc[:,1:-1]
    val_y=valdata.iloc[:,-1:]
    data=data.loc[model_index,:]
    x_data=data.iloc[:,1:-1]
    y_data=data.iloc[:,-1:]
    y_data.index=range(len(y_data))
    x_names=x_data.columns.values.tolist()
    colnames=y_data.columns.values.tolist()
    
    ss=ShuffleSplit(n_splits=10, test_size=0.1,random_state=0)
    #stdsc=StandardScaler()
    prelist=[]
    vallist=[]
    corlist_train=[]
    corlist_test=[]
    rmsel_train=[]
    rmsel_test=[]
    r2_train=[]
    r2_test=[]
    o=[]
    model = XGBRegressor(n_estimators=500
                                 , max_depth=9
                                 #, gamma=0.1
                                 ,reg_alpha=1
                                 ,learning_rate=0.1
                                 ,random_state=42)
    
    with tqdm(total=10) as pbar:
        for train_index , test_index in ss.split(x_data,y_data):
            x_train=x_data.iloc[train_index,:]
            x_train.columns=x_names
            y_train=y_data.iloc[train_index,:]            
            x_test=x_data.iloc[test_index,:]
            x_test.columns=x_names        
            y_test=y_data.iloc[test_index,:] 
            for k in [x_train, x_test]:
               k.index = range(k.shape[0])
            ''' 
             param_grid = {
             'max_depth': [6, 7, 8, 9],
             'n_estimators': np.linspace(500, 1000, 10, dtype=int),
              'learning_rate': [0.1,0.3, 0.05, 0.5],
             "gamma":[0.0, 0.1, 0.2, 0.3, 0.4]
#             , "reg_alpha":[0.0001,0.001, 0.01, 0.1, 1, 100]
#              "reg_lambda":[0.0001,0.001, 0.01, 0.1, 1, 100],
#              "min_child_weight": [2,3,4,5,6,7,8],
#              "colsample_bytree": [0.6, 0.7, 0.8, 0.9],
#             "subsample":[0.6, 0.7, 0.8, 0.9]
   }
            xgb_sk = XGBRegressor(random_state=42)
            grid_search = GridSearchCV(xgb_sk, param_grid, cv=10,
                             scoring='neg_mean_squared_error', return_train_score=True,n_jobs=-1)
            grid_search.fit(x_train,y_train)
            print("最佳度量值:",grid_search.best_score_)
            print("最佳参数:", grid_search.best_params_)
            print("最佳模型:", grid_search.best_estimator_)

            # 用最佳参数生成模型
            model = XGBRegressor(n_estimators=grid_search.best_params_['n_estimators']
                                 , max_depth=grid_search.best_params_['max_depth']
                                 , gamma=grid_search.best_params_['gamma']
                                 ,learning_rate=grid_search.best_params_['learning_rate']
                                 ,random_state=42) 
           # learning_rate=0.0001时模型的效果很差
            '''   
            model.fit(x_train,y_train)
            '''
            val_one=model.predict(val_x)
            vallist.append(val_one.T)
            pre_one=model.predict(predf)
            prelist.append(pre_one.T)
            '''
            caculate_cor()
            corlist_train.append(r_train[1,0])
            corlist_test.append(r_test[1,0])
            rmsel_train.append(rmse_train)
            rmsel_test.append(rmse_test)
            r2_train.append(train_R2)
            r2_test.append(test_R2)
            scatter_loss_plot()
            o.append(y_train[colnames[0]])
            o.append(y_train_pred[0])
            o.append(y_test[colnames[0]])
            o.append(y_test_pred[0])
            pbar.update()
        explainer = shap.Explainer(model)
        shap_values = explainer(x_train)

        # 绘制 SHAP 值重要性箱线图
        shap.summary_plot(shap_values, x_train, plot_type="bar", show=False)
        plt.title("SHAP Values Importance")
        plt.tight_layout()
        plt.savefig("C:/Users/Administrator/Desktop/2023/models/XGB/shap_values.png", dpi=300)
    #plt.show()        
    cordf=pd.DataFrame({'r2_train':r2_train,'r2_test':r2_test,
                        'train':corlist_train,'test':corlist_test,
                        'rmse_train':rmsel_train,'rmse_test':rmsel_test})
    obs_pre_df=pd.DataFrame([y_data[colnames[0]],o[1],o[5],o[9],o[13],o[17],o[21],o[25],o[29],o[33],o[37],
                            o[3],o[7],o[11],o[15],o[19],o[23],o[27],o[31],o[35],o[39]]).T
    obs_pre_df.columns=(colnames[0],'train1','train2','train3','train4','train5',
                        'train6','train7','train8','train9','train10',
                        'test1','test2','test3','test4','test5',
                        'test6','test7','test8','test9','test10')
    '''
    presult=pd.DataFrame(prelist,columns=['T','C','S','M','L']).T
    vresult=pd.DataFrame(vallist,columns=val).T
    vresult['observe']=val_y
    '''
    obs_pre_df.to_excel(writer1,sheet_name=colnames[0])
    cordf.to_excel(writer2,sheet_name=colnames[0])
    #presult.to_excel(writer4,sheet_name=colnames[0])
    #vresult.to_excel(writer5,sheet_name=colnames[0])
       
writer1.save()
writer2.save()
#writer3.save()
#writer4.save()
#writer5.save()

'''MLP'''
from keras import Sequential
from keras.layers.core import Dense,Activation,Dropout
from keras import optimizers
from tensorflow.keras.optimizers import SGD
from sklearn.neural_network import MLPRegressor
data=pd.read_csv("Desktop/2023/models/training.csv")
data_encoded = pd.get_dummies(data['Land_cover'])
data=pd.concat([data,data_encoded],axis=1)
#将某列移动到最后一列
col_to_move = 'EMF_mm'
data.info()
data = data.assign(**{col_to_move: data.pop(col_to_move)})
data.drop(['Land_cover','soil_age','bd','LSTd','LSTn','mammals','amphibians','soil biodiversity'],axis=1, inplace = True)

#model=MLPRegressor(activation='tanh'
                  # , learning_rate=0.0001
 #                  ,alpha=0.0001, hidden_layer_sizes=(1000,500,500))
#83-MLP-是alpha为0.1时建模

writer1=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/MLP/MLP-op-mm-multi.xlsx')
writer2=pd.ExcelWriter('C:/Users/Administrator/Desktop/2023/models/MLP/MLP-cor-mm-multi.xlsx')
#writer4=pd.ExcelWriter('821-val.xlsx')
#writer5=pd.ExcelWriter('821-pre.xlsx')
#writer6=pd.ExcelWriter('ss-index-all.xlsx')
for i in trange(2,3):
    #data=pd.read_excel('C:/Users/Administrator/Desktop/2023/models/MLP/RF20221009_821.xlsx',sheet_name=i)
    random.seed(2)
    model_index=list(data.index)
    val=random.sample(range(0,len(data)),5)
 
    for j in val:
        model_index.remove(j)
    #x_data=data[globals()['colindex'+str(i)]]
    valdata=data.iloc[val,:]
    val_x=valdata.iloc[:,1:-1]
    val_y=valdata.iloc[:,-1:]
    data=data.loc[model_index,:]
    x_data=data.iloc[:,1:-1]
    y_data=data.iloc[:,-1:]
    y_data.index=range(len(y_data))
    x_names=x_data.columns.values.tolist()
    colnames=y_data.columns.values.tolist()
    
    ss=ShuffleSplit(n_splits=10, test_size=0.1,random_state=0)
    #stdsc=StandardScaler()
    prelist=[]
    vallist=[]
    corlist_train=[]
    corlist_test=[]
    rmsel_train=[]
    rmsel_test=[]
    r2_train=[]
    r2_test=[]
    o=[]
    model=MLPRegressor(activation='tanh'
     #                  , learning_rate='adaptive'
                       ,alpha=0.1, hidden_layer_sizes=(1000,500,500))
    #model=MLPRegressor(activation='tanh'
     #                  , learning_rate='constant'
    #                   ,alpha=0.1
    #                   , hidden_layer_sizes=(1000,500,500))
    with tqdm(total=10) as pbar:
        for train_index , test_index in ss.split(x_data,y_data):
            x_train=x_data.iloc[train_index,:]
            x_train.columns=x_names
            y_train=y_data.iloc[train_index,:]            
            x_test=x_data.iloc[test_index,:]
            x_test.columns=x_names        
            y_test=y_data.iloc[test_index,:] 
            for k in [x_train, x_test]:
               k.index = range(k.shape[0])
            model.fit(x_train,y_train)
            '''
            val_one=model.predict(val_x)
            vallist.append(val_one.T)
            pre_one=model.predict(predf)
            prelist.append(pre_one.T)
            '''
            caculate_cor()
            corlist_train.append(r_train[1,0])
            corlist_test.append(r_test[1,0])
            rmsel_train.append(rmse_train)
            rmsel_test.append(rmse_test)
            r2_train.append(train_R2)
            r2_test.append(test_R2)
            #scatter_loss_plot()
            o.append(y_train[colnames[0]])
            o.append(y_train_pred[0])
            o.append(y_test[colnames[0]])
            o.append(y_test_pred[0])
            pbar.update()           

    plt.show()        
    cordf=pd.DataFrame({'r2_train':r2_train,'r2_test':r2_test,
                        'train':corlist_train,'test':corlist_test,
                        'rmse_train':rmsel_train,'rmse_test':rmsel_test})
    obs_pre_df=pd.DataFrame([y_data[colnames[0]],o[1],o[5],o[9],o[13],o[17],o[21],o[25],o[29],o[33],o[37],
                            o[3],o[7],o[11],o[15],o[19],o[23],o[27],o[31],o[35],o[39]]).T
    obs_pre_df.columns=(colnames[0],'train1','train2','train3','train4','train5',
                        'train6','train7','train8','train9','train10',
                        'test1','test2','test3','test4','test5',
                        'test6','test7','test8','test9','test10')
    '''
    presult=pd.DataFrame(prelist,columns=['T','C','S','M','L']).T
    vresult=pd.DataFrame(vallist,columns=val).T
    vresult['observe']=val_y
    '''
    obs_pre_df.to_excel(writer1,sheet_name=colnames[0])
    cordf.to_excel(writer2,sheet_name=colnames[0])
    #presult.to_excel(writer4,sheet_name=colnames[0])
    #vresult.to_excel(writer5,sheet_name=colnames[0])
       
writer1.save()
writer2.save()
#writer3.save()
#writer4.save()
#writer5.save()