library(piecewiseSEM)
library(lavaan)
library(semPlot)
library(plspm)
library(readxl)
library(vegan)
library(PerformanceAnalytics)
library(QuantPsyc)
library(nlme)
library(lme4)#加载包，没有的话需要安装

# 变量间的共线性分析 ---------------------------------------------------------------
# 导入数据
#data <-multi %>% mutate(abs_latitude= abs(lat))
data <- read.csv("training.csv",header = TRUE)
data<-data[complete.cases(data),]
predictors <- c("abs_latitude"#,"Land_cover"
                ,"MAT","MAP","aridity","soil_temp","HFP","elev"
                ,"phh2o" ,"cec"
                ,"difference"
                ,"sand","clay"
                ,"plant_SR","plant_PR"
                ,"bacteria_SR","bacteria_PD")
# 标准化数值型变量
data_scaled <- scale(data[,predictors]) %>% as.data.frame()
data1 <- data_scaled %>% mutate(data['Land_cover']) %>% mutate(data['EMF_mm'])
data <- data1
cor_matrix <- cor(data_scaled)
#编码因子变量
# Land_cover <- model.matrix(~ Land_cover - 1, data=data)
# head(Land_cover)
# data$Land_cover <-Land_cover
# head(data)
write.csv(data,file="SEMdata.csv",row.names = FALSE)
#读取上一步保存的数据文件夹
data <- read.csv("SEMdata.csv",header=T)


# 可视化相关系数矩阵
# library(corrplot)
# corrplot(cor_matrix, type="upper", method="color", order="hclust")
# 
# # 计算方差膨胀因子
# library(car)
# vif_result <- vif(lm(formula = EMF_mm ~ sand + HFP+ aridity + abs_latitude + cec + phh2o +
#                      + elev + soil_temp + difference  + MAT + MAP +clay 
#                      + plant_SR	
#                      + plant_PR +	bacteria_SR	+ bacteria_PD, data = data))
# vif_result 
# 
# # 分土地利用类型 -----------------------------------------------------------------

data <- data %>% filter(Land_cover == "C")
#气候变量的组合
model1 <- lm(EMF_mm ~  MAP + aridity  + difference + soil_temp + MAT, data)
coefs(model1, standardize = 'scale')
#气候变量拼接：

beta_MAP <- summary(model1)$coefficients[2, 1]
beta_aridity <-  summary(model1)$coefficients[3, 1]
beta_soil_temp <- summary(model1)$coefficients[5, 1]
beta_difference <-  summary(model1)$coefficients[4, 1]
beta_MAT <-  summary(model1)$coefficients[6, 1]
climate <-  beta_MAP * data$MAP + beta_aridity * data$aridity + beta_difference * data$difference + beta_soil_temp *data$soil_temp + beta_MAT * data$MAT
data$climate <- climate
summary(lm(EMF_mm ~ climate, data))
coefs(lm(EMF_mm ~ climate, data))

#生态系统类型变量的组合
# model2 <- lm(EMF_mm ~  Land_cover.Land_coverC + Land_cover.Land_coverD  +Land_cover.Land_coverF +  Land_cover.Land_coverG , data)
# summary(model2)$coefficients
# #coefs(model2, standardize = 'scale')
# beta_cropland <- summary(model2)$coefficients[2, 1]
# beta_forest <-  summary(model2)$coefficients[4, 1]
# #beta_grassland <- summary(model2)$coefficients[3, 1]
# #beta_unmanaged_grass <- summary(model2)$coefficients[5, 1]
# beta_sparse <-  summary(model2)$coefficients[3, 1]
# ecosystem <- beta_cropland * data$Land_cover.Land_coverC + beta_sparse * data$Land_cover.Land_coverD+ beta_forest *data$Land_cover.Land_coverF
# data$ecosystem <- ecosystem
# summary(lm(EMF_mm ~ ecosystem, data))
# coefs(lm(EMF_mm ~ ecosystem, data))


#土壤变量的组合
model3 <- lm(EMF_mm ~ phh2o  + sand + cec + clay, data)
coefs(model3, standardize = 'scale')
beta_phh2o <- summary(model3)$coefficients[2, 1]
beta_clay <-  summary(model3)$coefficients[5, 1]
beta_sand <- summary(model3)$coefficients[3, 1]
beta_cec <- summary(model3)$coefficients[4, 1]
soil <- beta_phh2o * data$phh2o + beta_sand * data$sand + beta_cec * data$cec + beta_clay *data$clay
data$soil <- soil
summary(lm(EMF_mm ~ soil, data))
coefs(lm(EMF_mm ~ soil, data))

#地理变量的组合

#地理变量的组合
model0 <- lm(EMF_mm ~ abs_latitude + elev, data)
coefs(model0, standardize = 'scale')
beta_abs_latitude <-  summary(model0)$coefficients[2, 1]
beta_elev <- summary(model0)$coefficients[3, 1]
geography <- beta_abs_latitude * data$abs_latitude + beta_elev * data$elev
data$geography <- geography
summary(lm(EMF_mm ~ geography, data))
coefs(lm(EMF_mm ~ geography, data))

#生物变量的组合
model4 <- lm(EMF_mm ~	bacteria_SR	+ bacteria_PD, data)
coefs(model4, standardize = 'scale')
beta_bacteria_SR<-  summary(model4)$coefficients[2, 1]
beta_bacteria_PD <- summary(model4)$coefficients[3, 1]
biodiversity <- beta_bacteria_SR *data$bacteria_PD + beta_bacteria_PD*data$bacteria_SR
data$biodiversity <- biodiversity
summary(lm(EMF_mm ~ biodiversity, data))
coefs(lm(EMF_mm ~ biodiversity, data))

model5 <- lm(EMF_mm ~ plant_SR	+ plant_PR , data)
coefs(model5, standardize = 'scale')
beta_plant_SR<-  summary(model5)$coefficients[2, 1]
beta_plant_PR <- summary(model5)$coefficients[3, 1]
plant <- beta_plant_SR * data$plant_SR + beta_plant_PR * data$plant_PR
data$plant <- plant
summary(lm(EMF_mm ~ plant, data))
coefs(lm(EMF_mm ~ plant, data))


#基于混合效应模型的多元回归
data$Site <- 1:nrow(data)
microbe.list <- list(
  lme(climate ~ geography , random = ~ 1 | Site, na.action = na.omit,
    data = data),
   # lme(ecosystem ~ climate , random = ~ 1 | Site , na.action = na.omit,
   #     data = data),
  lme(biodiversity ~ climate + HFP , random = ~ 1 | Site, na.action = na.omit,
      data = data),
  lme(plant_PR ~   soil + climate + HFP, random = ~ 1 | Site , na.action = na.omit,
      data = data), 
  lme(EMF_mm ~   climate  + soil + biodiversity + plant_PR + HFP, random = ~ 1 | Site , na.action = na.omit,
      data = data)
)
#SEM
microbe.psem <- as.psem(microbe.list)
(new.summary <- summary(microbe.psem, .progressBar = F))
plot(microbe.psem)



preddata <- readRDS("eachyear/0524_full_2018.rds")
preddata<-preddata[complete.cases(preddata),]

Land_cover <- model.matrix(~ Land_cover - 1, data=preddata)
head(Land_cover)
# #用转化为0/1的数据矩阵赋值替换原数据中的因子变量
preddata$Land_cover <-Land_cover
head(preddata)
write.csv(preddata,file="SEMpreddata.csv",row.names = FALSE)
#读取上一步保存的数据文件夹
preddata <- read.csv("SEMpreddata.csv",header=T)
dt1 <- subset(preddata,difference > 15)


model1 <- lm(prediction ~  MAP + aridity  + difference + soil_temp + MAT, dt1)
coefs(model1, standardize = 'scale')
#气候变量拼接：
#beta_MAT <-  summary(model1)$coefficients[2, 1]
beta_MAP <- summary(model1)$coefficients[2, 1]
beta_aridity <-  summary(model1)$coefficients[3, 1]
beta_soil_temp <- summary(model1)$coefficients[5, 1]
beta_difference <-  summary(model1)$coefficients[4, 1]
beta_MAT <-  summary(model1)$coefficients[6, 1]
climate <-  beta_MAP * dt1$MAP + beta_aridity * dt1$aridity + beta_difference * dt1$difference + beta_soil_temp *dt1$soil_temp + beta_MAT * dt1$MAT
dt1$climate <- climate
summary(lm(prediction ~ climate, dt1))
coefs(lm(prediction ~ climate, dt1))

#生态系统类型变量的组合
model2 <- lm(prediction ~  Land_cover.Land_coverC + Land_cover.Land_coverD  +Land_cover.Land_coverF +  Land_cover.Land_coverG , dt1)
summary(model2)$coefficients
#coefs(model2, standardize = 'scale')
beta_cropland <- summary(model2)$coefficients[2, 1]
beta_forest <-  summary(model2)$coefficients[4, 1]
#beta_grassland <- summary(model2)$coefficients[3, 1]
#beta_unmanaged_grass <- summary(model2)$coefficients[5, 1]
beta_sparse <-  summary(model2)$coefficients[3, 1]
ecosystem <- beta_cropland * dt1$Land_cover.Land_coverC + beta_sparse * dt1$Land_cover.Land_coverD+ beta_forest *dt1$Land_cover.Land_coverF
dt1$ecosystem <- ecosystem
summary(lm(prediction ~ ecosystem, dt1))
coefs(lm(prediction ~ ecosystem, dt1))


#土壤变量的组合
model3 <- lm(prediction ~ phh2o  + sand + cec + clay, dt1)
coefs(model3, standardize = 'scale')
beta_phh2o <- summary(model3)$coefficients[2, 1]
beta_clay <-  summary(model3)$coefficients[5, 1]
beta_sand <- summary(model3)$coefficients[3, 1]
beta_cec <- summary(model3)$coefficients[4, 1]
soil <- beta_phh2o * dt1$phh2o + beta_sand * dt1$sand + beta_cec * dt1$cec + beta_clay *dt1$clay
dt1$soil <- soil
summary(lm(prediction ~ soil, dt1))
coefs(lm(prediction ~ soil, dt1))

#地理变量的组合

#地理变量的组合
model0 <- lm(prediction ~ abs_latitude + elev, dt1)
coefs(model0, standardize = 'scale')
beta_abs_latitude <-  summary(model0)$coefficients[2, 1]
beta_elev <- summary(model0)$coefficients[3, 1]
geography <- beta_abs_latitude * dt1$abs_latitude + beta_elev * dt1$elev
dt1$geography <- geography
summary(lm(prediction ~ geography, dt1))
coefs(lm(prediction ~ geography, dt1))

#生物变量的组合
model4 <- lm(prediction ~	bacteria_SR	+ bacteria_PD, dt1)
coefs(model4, standardize = 'scale')
beta_bacteria_SR<-  summary(model4)$coefficients[2, 1]
beta_bacteria_PD <- summary(model4)$coefficients[3, 1]
biodiversity <- beta_bacteria_SR *dt1$bacteria_PD + beta_bacteria_PD*dt1$bacteria_SR
dt1$biodiversity <- biodiversity
summary(lm(prediction ~ biodiversity, dt1))
coefs(lm(prediction ~ biodiversity, dt1))

model5 <- lm(prediction ~ plant_SR	+ plant_PR , dt1)
coefs(model5, standardize = 'scale')
beta_plant_SR<-  summary(model5)$coefficients[2, 1]
beta_plant_PR <- summary(model5)$coefficients[3, 1]
plant <- beta_plant_SR * dt1$plant_SR + beta_plant_PR * dt1$plant_PR
dt1$plant <- plant
summary(lm(prediction ~ plant, dt1))
coefs(lm(prediction ~ plant, dt1))
#基于混合效应模型的多元回归


dt1$Site <- 1:nrow(dt1)
microbe.list <- list(
  lme(climate ~ geography , random = ~ 1 | Site, na.action = na.omit,
    data = data),
  lme(ecosystem ~ climate , random = ~ 1 | Site , na.action = na.omit,
      data = dt1),
  lme(biodiversity ~ climate + HFP , random = ~ 1 | Site, na.action = na.omit,
      data = dt1),
  lme(plant_PR ~ soil + climate + HFP, random = ~ 1 | Site , na.action = na.omit,
      data = dt1), 
  lme(prediction ~  climate + ecosystem + soil + biodiversity + plant_PR + HFP, random = ~ 1 | Site , na.action = na.omit,
      data = dt1)
)
#SEM
microbe.psem <- as.psem(microbe.list)
(new.summary <- summary(microbe.psem, .progressBar = F))
plot(microbe.psem)


