library(corrplot)
library(ggpubr)
source("your_script.R")
cordata <- readxl::read_excel("corplot/parameter.xlsx")
#%>% select(-"Land_cover") %>% na.omit()
cordata <- readxl::read_excel("cordata.xlsx") %>% filter(Land_cover == "C") %>% na.omit()%>% select(-"Land_cover") 
tdc <- cor (phy,met, method="pearson")
testRes = cor.mtest(cordata, menthod = "pearson", conf.level = 0.95)

# 假设你的数据框 tdc 包含多列数据

# 计算相关性矩阵

corrplot(tdc, method = "circle", 
         type = "upper",
         tl.col = "black", tl.cex = 1.2, tl.srt = 45
)

phy <-readxl::read_excel("corplot/cordata_d.xlsx") 
met <-readxl::read_excel("parameter.xlsx")
cor <-corr.test(phy, met, method = "pearson",adjust="none")
#提取相关性、p值
cmt <-cor$r
pmt <- cor$p
head(cmt)
cmt.out<-cbind(rownames(cmt),cmt)
write.table(cmt.out,file="cor.txt",sep="\t",row.names=F)
df <-melt(cmt,value.name="cor")
df$pvalue <-as.vector(pmt)
head(df)
write.table(df,file="cor-p.txt",sep="\t")
if (!is.null(pmt)){
  ssmt <- pmt< 0.01
  pmt[ssmt] <-'**'
  smt <- pmt >0.01& pmt <0.05
  pmt[smt] <- '*'
  pmt[!ssmt&!smt]<- ''
} else {
  pmt <- F
}
library(pheatmap)
#自定义颜色范围
mycol<-colorRampPalette(c("blue","white","tomato"))(800)
#绘制热图,可根据个人需求调整对应参数
#scale=”none” 不对数据进行均一化处理 可选"row", "column"对行、列数据进行均一化
#cluster_row/col=T 对行或列数据进行聚类处理，可选F为不聚类
#border=NA 各自边框是否显示、颜色，可选“white”等增加边框颜色
#number_color=”white” 格子填入的显著性标记颜色
#cellwidth/height=12 格子宽度、高度信息

pheatmap(cmt,scale = "none",cluster_row = F, cluster_col = F, border=NA,
         display_numbers = pmt,fontsize_number = 12, number_color = "white",
         cellwidth = 20, cellheight =20,color=mycol)
pheatmap(cmt,scale = "none",cluster_row = F, cluster_col = F, border=NA,
         display_numbers = pmt, fontsize_number = 12, number_color ="white",
         cellwidth = 20, cellheight =20,color=mycol,filename="corplot/heatmap_d.pdf")
