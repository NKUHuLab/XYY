library(jsonlite)
library(ggplot2)
library(MASS)
library(reshape2)
library(boot)
library(dplyr)
library(segmented)
library(chngpt)
library(gam)
library(snow)
#setwd("C:/Users/Administrator/Desktop/2022/2022-09/threshold")
df=read.csv('define para.csv')
predictors <- c("abs_latitude","Land_cover","MAT","MAP","aridity","soil_temp","HFP","elev"
                ,"phh2o" ,"cec"
                ,"difference"
                ,"sand","clay"
                ,"plant_SR","plant_PR"
                ,"bacteria_SR","bacteria_PD")

dff=data.frame(y=df$Soil.water.content,x=df$difference)
dff=dff[complete.cases(dff),]

######
mdl=Mymodels(dff)
AICs=MyAICs(mdl)

##1)Find AICs
Mymodels=function(dff,fml="gaussian"){
  models=list(
    linear=glm(data=dff,formula=y~x,family = fml),
    quad=glm(data = dff,formula = y~poly(x,degree = 2),family = fml),
    gm=gam(data = dff,formula = y~s(x),family = fml),
    stegmented=chngptm(formula.1 = y~1,formula.2 = ~x,data = dff,type="stegmented",family = fml,chngpt.init = 0.7),
    stepm=chngptm(formula.1 = y~1,formula.2 = ~x,data = dff,type="step",family = fml),
    pw1=chngptm(formula.1 = y~1,formula.2 = ~x,data = dff,type="segmented",family = fml))
  
  return(models)
}
MyAICs=function(models){
  AICs=with(models,c(AICLin=AIC(linear),
                     AICQuad=AIC(quad),
                     AICgam=gm$aic,
                     AICSteg=stegmented$best.fit$aic,
                     AICStep=stepm$best.fit$aic,
                     AIC.pw1=pw1$best.fit$aic))
  return(AICs)
}

#1) AICs
######
mdl=Mymodels(dff)
AICs=MyAICs(mdl)
#主要的自助法函数是boot()，它的格式为：bootobject<-boot(data=,statistic=,R=,…)
results=boot(data = dff,statistic = bs,R=200)
dfboot=as.data.frame(results$t)
colnames(dfboot)=c("thresSteg1",
                   "thresStep1",
                   "thresSeg1",
                   "thresSteg2",
                   "thresStep2",
                   "thresSeg2")
write.csv(dfboot,"filename.csv")

#In the particular case GAM is the best model and the figure suggest the existence of 2 thresholds changing the slope (photosynthesis under controlled conditions).
#We do it manually with segmented; remember, segmented do a bootstrap to find coefficients, so another one is not necessary




#TO PLOT: IMPORTANT
Size=c(14.34042,13.46729)
Size=Size*0.3
Wi=Size[1]
He=Size[2]
##
##
thres1 =  10.780464630 

dff$grupo=2
dff$grupo[dff$x<thres1]=1

p<-ggplot(dff,aes(x = x,y=y))+
    theme_classic()+
    geom_point(size=2.5,col="orange4")+
    geom_smooth(aes(group=grupo),method="lm",fill=NA,size=1.8)+
   geom_smooth(color="black",fill=NA,linetype="longdash",size=1.8)+
   geom_vline(xintercept = thres1,linetype="dashed",size=1.8)+
    annotate("text", x = thres1+0.05, y = 0.95,
                          parse = TRUE,
                         label = as.character(round(thres1,digits = 2)),
                         color="red",
                          fontface="bold",
                          size=1.8) +
   ylab("Soil water content\n(Normalization)")+
   xlab("LST_diff(°C)")+
    scale_x_continuous(limits=c(0,35),breaks=seq(0,35,by=10),expand=c(0,0)) + 
   scale_y_continuous(limits=c(0,0.99),breaks=seq(0,0.99,by=.2),expand=c(0,0))+
   theme(axis.line=element_line(linetype=1,color="black",size=2.2),
                   plot.margin=unit(c(0.1,0.1,0.1,0.1),"cm"),
                   axis.ticks.length = unit(0.4*0.25,"cm"),
                   axis.text=element_text(size=44,face = "bold"),
                   axis.title.y = element_text(size=45,face = "bold"),
                   axis.title.x = element_text(size=50,face="bold"))
p
ggsave("lst_swc.png",p,width = 8, height = 8,dpi=1000)
