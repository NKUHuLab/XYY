# ************* tmst.R *************
# create timestamp

tmst <- function(ext = NULL, time = T, prefix = "_c") {
  
  if (time) {
    paste0(prefix, format(Sys.time(), "%Y-%m-%d_%H%M%S"), ext)
  } else {
    paste0(prefix, format(Sys.time(), "%Y-%m-%d"), ext)
  }
}

# #############import resample --------------------------------------------


# resamp<-function(ras){
#   refer_res<-raster('D:/futureclimate/ACCESS-CM2/wc2.1_5m_bioc_ACCESS-CM2_ssp370_2021-2040.tif',band=1)
#   resample(ras,refer_res,methods="bilinear")
# }
#fix extent
rextent<-function(ras){
  refer<-raster('resample/dynamic/Land_cover/Land_cover_2006.tif')
  resample(ras,refer,methods="bilinear")
}
glc_get_nolandcover <- function(layer) {
  slgrds <- c("aridity","cec","clay","phh2o","sand","elev","plant_SR","plant_PR"
              ,"bacteria_SR","bacteria_PD")
  others <- c("MAT","MAP","soil_temp","HFP","difference")
  if (layer %in% slgrds) {
    rpath <- here("resample/static/",paste0("resamp_",layer,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
  } else if (layer %in% others) {
    rpath <- here("resample/",paste0(layer,"_mean.tif"))
    ras <- raster::raster(rpath) %>% rextent()
  }
  # } else if (layer == "Land_cover"){
  #   rpath <- here("resample/",paste0("resamp_lcss.tif"))
  #   ras <- raster::raster(rpath)
  # }
  else {
    stop("Not a valid layer")
  }
  ras
}
glc_get_raster <- function(layer) {
  slgrds <- c("aridity","cec","clay","phh2o","sand","elev","plant_SR","plant_PR"
              ,"bacteria_SR","bacteria_PD")
  others <- c("MAT","MAP","soil_temp","HFP","difference")
  if (layer %in% slgrds) {
    rpath <- here("resample/static/",paste0("resamp_",layer,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
  } else if (layer %in% others) {
    rpath <- here("resample/",paste0(layer,"_mean.tif"))
    ras <- raster::raster(rpath) %>% rextent()
  }
    else if (layer == "Land_cover"){
     rpath <- here("resample/dynamic/Land_cover/Land_cover_2006.tif")
     ras <- raster::raster(rpath) 
  } else {
    stop("Not a valid layer")
  }
  ras
}
  

get_resample_raster<-function(layer,year=NULL){
  slgrds <- c("aridity","cec","clay","phh2o","sand","elev","plant_SR","plant_PR"
              ,"bacteria_SR","bacteria_PD"
              ,"mammals","amphibians")
  dynamic <- c("MAT","MAP","soil_temp","HFP","difference","Land_cover")
  
  if (layer %in% slgrds){
    rpath <- here("resample/static/", paste0("resamp_",layer,".tif")) 
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "MAT"){
    rpath <- here("resample/dynamic/MAT/",paste0(layer,"_",year,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "MAP"){
    rpath <- here("resample/dynamic/MAP/",paste0(layer,"_",year,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "soil_temp"){
    rpath <- here("resample/dynamic/soil_temp/",paste0(layer,"_",year,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "difference"){
    rpath <- here("resample/dynamic/difference/",paste0(layer,"_",year,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "Land_cover"){
    rpath <- here("resample/dynamic/Land_cover/",paste0(layer,"_",year,".tif"))
    ras <- raster::raster(rpath) 
    
  } else if (layer == "HFP"){
    rpath <- here("resample/dynamic/HFP/",paste0(layer,"_",year,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else {
    stop("Not a valid layer")
  }
  ras
}
vars <- c("Land_cover","MAT","MAP","aridity","soil_temp","HFP","elev"
          ,"phh2o" ,"cec"
          ,"difference"
          ,"sand","clay"#,"abs_latitude"
          ,"plant_SR","plant_PR"
          ,"bacteria_SR","bacteria_PD")
#fix extent
extent<-function(ras){
 # ras <- as(ras, "RasterLayer")
  refer<-raster('resample/dynamic/Land_cover/Land_cover_2006.tif')
  projectRaster(ras,refer,method = "ngb")
}

# extent <- function(ras){
#   r1 <- raster('resample/dynamic/Land_cover/Land_cover_2006.tif')
#   e1 <- extent(r1)
#   e2 <- extent(ras)
#   e_union <- union(e1, e2)
#   ras <- crop(ras, e_union)
# }

get_future_lui<-function(layer,GCMs= NULL,serino=NULL, iyear=NULL){
  slgrds <- c("cec","clay","phh2o","sand","aridity","elev","plant_SR","plant_PR"
              ,"bacteria_SR","bacteria_PD")
  
  dynamic <- c("MAT","MAP","soil_temp","HFP","difference","Land_cover")
  
  if (layer %in% slgrds){
    rpath <- here("resample/static/", paste0("resamp_",layer,".tif")) 
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "MAT"){
    rpath <- here("resample/dynamic/MAT/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath)  %>% rextent()
    
  } else if (layer == "MAP"){
    rpath <- here("resample/dynamic/MAP/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath)  %>% rextent()
    
  } else if (layer == "soil_temp"){
    rpath <- here("resample/dynamic/soil_temp/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "difference"){
    rpath <- here("resample/dynamic/difference/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "Land_cover"){
    rpath <- here("futureclimate/resample/",paste0(serino,"_",layer,"_",iyear,".tif"))
    ras <- raster::raster(rpath) %>% extent()
    
  } else if (layer == "HFP"){
    rpath <- here("resample/dynamic/HFP/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else {
    stop("Not a valid layer")
  }
  ras
}

get_future_climate<-function(layer,GCMs= NULL,serino=NULL, iyear=NULL){
  slgrds <- c("cec","clay","phh2o","sand","aridity","elev","plant_SR","plant_PR"
              ,"bacteria_SR","bacteria_PD")
  
  dynamic <- c("MAT","MAP","soil_temp","HFP","difference","Land_cover")
  
  if (layer %in% slgrds){
    rpath <- here("resample/static/", paste0("resamp_",layer,".tif")) 
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "MAT"){
    rpath <- here("futureclimate/",paste0("wc2.1_5m_bioc_",GCMs,"_",serino,"_",iyear,"_",layer,".tif"))
    ras <- raster::raster(rpath)  %>% rextent()
    
  } else if (layer == "MAP"){
    rpath <- here("futureclimate/",paste0("wc2.1_5m_bioc_",GCMs,"_",serino,"_",iyear,"_",layer,".tif"))
    ras <- raster::raster(rpath)  %>% rextent()
    
  } else if (layer == "soil_temp"){
    rpath <- here("resample/dynamic/soil_temp/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "difference"){
    rpath <- here("resample/dynamic/difference/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "Land_cover"){
    rpath <- here("resample/dynamic/Land_cover/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath) %>% extent()
    
  } else if (layer == "HFP"){
    rpath <- here("resample/dynamic/HFP/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else {
    stop("Not a valid layer")
  }
  ras
}
get_future_raster<-function(layer,GCMs= NULL,serino=NULL, iyear=NULL){
  slgrds <- c("cec","clay","phh2o","sand","aridity","elev","plant_SR","plant_PR"
              ,"bacteria_SR","bacteria_PD")
  
  dynamic <- c("MAT","MAP","soil_temp","HFP","difference","Land_cover")
  
  if (layer %in% slgrds){
    rpath <- here("resample/static/", paste0("resamp_",layer,".tif")) 
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "MAT"){
    rpath <- here("futureclimate/",paste0("wc2.1_5m_bioc_",GCMs,"_",serino,"_",iyear,"_",layer,".tif"))
    ras <- raster::raster(rpath)  %>% rextent()
    
  } else if (layer == "MAP"){
    rpath <- here("futureclimate/",paste0("wc2.1_5m_bioc_",GCMs,"_",serino,"_",iyear,"_",layer,".tif"))
    ras <- raster::raster(rpath)  %>% rextent()
    
  } else if (layer == "soil_temp"){
    rpath <- here("resample/dynamic/soil_temp/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "difference"){
    rpath <- here("resample/dynamic/difference/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "Land_cover"){
    rpath <- here("futureclimate/resample/",paste0(serino,"_",layer,"_",iyear,".tif"))
    ras <- raster::raster(rpath) %>% extent()

  } else if (layer == "HFP"){
    rpath <- here("resample/dynamic/HFP/",paste0(layer,"_",2018,".tif"))
    ras <- raster::raster(rpath) %>% rextent()
    
  } else {
    stop("Not a valid layer")
  }
  ras
}

#' glc_Land_cover_classes
#'
#' @return tibble with Land_cover values used
#' @export
glc_Land_cover_classes_future <- function(){
  tibble::tribble(
    ~code, ~value,          ~class,
    "C",    1L,          "cropland",
    "C",    2L,          "cropland",
    "C",    3L,          "cropland",
    "C",    4L,          "cropland",
    "C",    5L,          "cropland",
    "F",   7L,             "forest",
    "F",   10L,            "forest",
    "G",   6L,          "grassland",
    "G",   9L,          "grassland",
    "D",   8L,      "sparse/no vegetation",
    "D",   11L,      "sparse/no vegetation"
  )
}
glc_LC_num2chr_future <- function(x) {
  tibble(value = x) %>%
    left_join(glc_Land_cover_classes_future()[1:2], by = "value") %>%
    dplyr::select(Land_cover = code) %>%
    dplyr::mutate(Land_cover = as.factor(Land_cover)) %>%
    pull
  
}
glc_Land_cover_classes <- function(){
  tibble::tribble(
    ~code, ~value,          ~class,
    "F",    1L     ,"forest",
    "F",    2L     ,"forest",
    "F",    3L     ,"forest",
    "F",    4L     ,"forest",
    "F",    5L     ,"forest",
    "F",    6L     ,"forest",
    "F",    7L     ,"forest",
    "F",    8L     ,"forest",
    "G",    9L,  "grassland",
    "G",    10L,  "grassland",
    "C",    12L,   "cropland",
    "C",    14L,   "cropland",
    "D",    16L,  "sparse/no vegetation"
  )
}

#' LC numeric to character
#'
#' @param x numeric vector of land cover codes
#'
#' @return character vector as factor
#' @export
glc_LC_num2chr <- function(x) {
  tibble(value = x) %>%
    left_join(glc_Land_cover_classes()[1:2], by = "value") %>%
    dplyr::select(Land_cover = code) %>%
    dplyr::mutate(Land_cover = as.factor(Land_cover)) %>%
    pull
  
}

# 预测微生物多样性地图 --------------------------------------------------------------
rextent<-function(ras){
  refer<-raster('resample/dynamic/Land_cover/Land_cover_2006.tif',band=1)
  resample(ras,refer,methods="bilinear")
}
get_static_raster<-function(layer){
  slgrds <- c("Mean_Diurnal_Range","ET0"
              ,"Temperature_Seasonality","Precipitation_Seasonality","Annual_Mean_Temperature","Annual_Precipitation"
              ,"Aridity","soil_temp"
              ,"Elevation"#,"ABS_latitude"
              ,"Bulk_Density"#,"Soil_age"
              ,"pH","CEC"
              ,"Sand"
              ,"Clay")
  
  if (layer %in% slgrds){
    rpath <- here("1978-2000/", paste0("resamp_",layer,".tif")) 
    ras <- raster::raster(rpath) %>% rextent()
    
  } else if (layer == "Land_cover"){
    rpath <- here("resample/dynamic/Land_cover/",paste0("Land_cover_2006.tif"))
    ras <- raster::raster(rpath) %>% rextent()
  } else {
    stop("Not a valid layer")
  }
  ras
}

# ********** misc.R **********

#' glc_Land_cover_classes
#'
#' @return tibble with Land_cover values used
#' @export
glc_Land_cover_classes <- function(){
     tibble::tribble(
       ~code, ~value,          ~class,
       "F",    1L     ,"forest",
       "F",    2L     ,"forest",
       "F",    3L     ,"forest",
       "F",    4L     ,"forest",
       "F",    5L     ,"forest",
       "F",    6L     ,"forest",
       "F",    7L     ,"forest",
       "F",    8L     ,"forest",
       "G",    9L,  "grassland",
       "G",    10L,  "grassland",
       "C",    12L,   "cropland",
       "C",    14L,   "cropland",
       "D",    16L,  "sparse/no vegetation"
     )
}

#' LC numeric to character
#'
#' @param x numeric vector of land cover codes
#'
#' @return character vector as factor
#' @export
glc_LC_num2chr <- function(x) {
  tibble(value = x) %>%
    left_join(glc_Land_cover_classes()[1:2], by = "value") %>%
    dplyr::select(Land_cover = code) %>%
    dplyr::mutate(Land_cover = as.factor(Land_cover)) %>%
    pull
  
}


#' LC character to numeric
#'
#' @param x character vector of land cover values
#'
#' @return numeric vector
#' @export
glc_LC_chr2num <- function(x) {
  tibble(code = x) %>%
    left_join(glc_Land_cover_classes()[1:2], by = "code") %>%
    select(Land_cover = value) %>%
    # mutate(Land_cover = as.factor(Land_cover)) %>%
    pull
  
}


# maha cmic
mahadist <- function (dat, world, vars, xy = c("x", "y")){
  #check names in both df, stop if not
  
  stopifnot(all(c(vars %in% names(dat), vars %in% names(world))))
  
  dat_sub <- dat %>% dplyr::select(all_of(vars)) %>%
    tidyr::drop_na()
  
  
  dat_diff_nrow <- nrow(dat) - nrow(dat_sub)
  if (dat_diff_nrow > 0) {
    message(dat_diff_nrow, " dat entries with NA values removed")
  }
  
  world_sub <- world %>% dplyr::select(all_of(xy), all_of(vars)) %>%
    tidyr::drop_na()
  
  wrld_diff_nrow <- nrow(world) - nrow(world_sub)
  if (wrld_diff_nrow > 0) {
    message(wrld_diff_nrow, " dat entries with NA values removed")
  }
  
  world_calc <- world_sub %>% dplyr::select(-c(all_of(xy)))
  
  mu <- colMeans(dat_sub) #vector of means
  sigma <- cov(dat_sub) #covariance matrix
  limit97 <- qchisq(.975, df = length(dat_sub))
  limit75 <- qchisq(.75, df = length(dat_sub))
  limit50 <- qchisq(.5, df = length(dat_sub))
  
  mahaDist <- mahalanobis(world_calc, mu, sigma)
  
  world_calc <- world_calc %>%
    mutate(mahaDistance = mahaDist,
           mahatype = case_when(
             is.na(mahaDist) ~ NA_character_,
             mahaDistance < limit50 ~ "<0.50",
             mahaDistance < limit75 ~ "0.50-0.75",
             mahaDistance < limit97 ~ "0.75-0.975",
             mahaDistance > limit97 ~ ">0.975(Outliers)"
           ))#????mahatype??
  
  world_calc <- world_calc %>%
    mutate(mahatype = factor(world_calc$mahatype,
                             levels = c("<0.50", "0.50-0.75", "0.75-0.975",">0.975(Outliers)")))
  
  outliers <- length(which(world_calc$mahaDistance > limit97))
  # world_calc %>% filter(mahatype == "chisq > 0.975") %>% nrow #check
  
  message(paste0(outliers, " outliers at 97.5% limit (", round(outliers/nrow(world_calc)*100, 2), "%)"))
  
  world_calc <- bind_cols(world_sub %>% dplyr::select(all_of(xy)), world_calc)
  
  return(world_calc)
  
}


draw_key_polygon3 <- function(data, params, size) {
  lwd <- min(data$size, min(size) / 4)
  
  grid::rectGrob(
    width = grid::unit(0.8, "npc"),
    height = grid::unit(0.8, "npc"),
    gp = grid::gpar(
      col = NA,
      fill = alpha(data$fill, data$alpha),
      lty = data$linetype,
      lwd = lwd * .pt,
      linejoin = "mitre"
    ))
}


glc_pIDfromXY <- function(x, y, csiz = 0.08333) {
  
  assertthat::assert_that(all(between(x, -180, 180)),
                          all(between(y, -90, 90)))
  
  x <- round(x, 5)
  y <- round(y, 5)
  
  nccol <- 2*180/csiz
  ncrow <- 2*90/csiz
  
  cellcol <- (x + 180) / csiz + 0.08333
  cellrow <- (90 - y) / csiz + 0.08333
  pID <- (cellrow-1) * nccol + cellcol
  pID %>% round %>% as.integer
  
}


#' XY from pID
#'
#' @param pid point ID number, equivalent to raster cell number
#' @param csiz cell size. Default to 0.05
#'
#' @return matrix of x and y values
#' @export
#'
#' @examples df %>% bind_cols(glc_XYfrompID(pid))
glc_XYfrompID <- function(pid, csiz = 0.08333) {
  pid <- pid %>% as.numeric %>% round %>% as.integer
  
  nccol <- 2*180/csiz
  ncrow <- 2*90/csiz
  
  cellrow <- pid %/% nccol + 1
  cellcol <- pid %% nccol
  
  y <- 90 - (cellrow - 0.08333) * csiz
  x <- -180 + (cellcol - 0.08333) * csiz
  
  tibble(x = x, y = y)
  
}


#' X from pID
#'
#' @inheritParams glc_XYfrompID
#'
#' @return point ID
#' @export
#'
#' @examples df %>% mutate(x = glc_XfrompID(pid),
#' y = glc_YfrompID(pid))
glc_XfrompID <- function(pid, csiz = 0.083333333333) {
  XYfrompID(pid, csiz)[,1]
  
}


#' Y from pID
#'
#' @inheritParams glc_XYfrompID
#'
#' @return point ID
#' @export
#'
#' @examples df %>% mutate(x = glc_XfrompID(pid),
#' y = glc_YfrompID(pid))
glc_YfrompID <- function(pid, csiz = 0.083333333333) {
  XYfrompID(pid, csiz)[,2]
  
}

#这段代码定义了一个名为df_slope_lm的函数，它接受一个数据框df和一个可选参数min_val。
#函数的作用是计算df中预测值(prediction)和年份(year)之间的线性回归斜率(slope)和p值(pval)，
#以及数据框中非缺失值的数量(nent)。如果数据框中的非缺失值数量小于min_val，则slope和pval被设置为NA。

#在函数中，首先使用nrow函数计算数据框中的非缺失值数量nent。然后，如果nent小于min_val，
#则slope和pval被设置为NA。否则，使用lm函数拟合预测值和年份之间的线性回归模型，
#并从模型系数中提取斜率。同时，使用summary函数获取模型系数的摘要信息，并从中提取p值。
#最后，将slope、pval和nent作为一个向量返回。

#因此，当调用df_slope_lm函数时，它将返回一个包含斜率、p值和非缺失值数量的向量。
#具体的斜率和p值取决于输入数据框df中预测值和年份之间的线性关系。


df_slope_lm <- function(df, min_val = 5){
  
  nent <- nrow(df)  #!is.na(df$stock)
  
  if (nent < min_val){
    slope <- pval <- NA
    
  } else { #lm
    
    mod <- lm(prediction ~ year, data = df)
    slope <- coef(mod)[2]
    pval <- summary(mod)$coefficients["year", "Pr(>|t|)"]
    
  }
  
  c(slope = slope, pval = pval, n = nent) #use list if n should be integer
  
}

